//! Fixed seven-neighbor convolutions, vectorized across the sixteen outputs.
use super::super::{
    FEATURES,
    spatial::{self, EMBEDDING, KERNEL, SpatialBoard},
};
use pulp::{Simd, WithSimd};

struct ConvolutionLayer {
    channels: usize,
    weights: Vec<f32>, // input channel, kernel position, output channel
    bias: Vec<f32>,
}

pub(super) struct ConvolutionEncoder {
    layers: Vec<ConvolutionLayer>,
    arch: pulp::Arch,
    height: usize,
    width: usize,
    mask: Vec<f32>,
    sites: Vec<usize>,
    neighbors: Vec<[usize; 7]>,
    first: Vec<f32>,
    embedding: Vec<f32>,
}

impl ConvolutionEncoder {
    pub(super) fn new(encoder: &spatial::SpatialEncoder) -> Self {
        let layers = encoder
            .convolutions
            .iter()
            .map(|conv| {
                let mut weights = vec![0.; conv.weights.len()];
                for channel in 0..conv.input_channels {
                    for k in 0..7 {
                        for out in 0..EMBEDDING {
                            weights[(channel * 7 + k) * EMBEDDING + out] =
                                conv.weights[(out * conv.input_channels + channel) * 7 + k];
                        }
                    }
                }
                ConvolutionLayer {
                    channels: conv.input_channels,
                    weights,
                    bias: conv.bias.clone(),
                }
            })
            .collect();
        Self {
            layers,
            arch: pulp::Arch::new(),
            height: 0,
            width: 0,
            mask: Vec::new(),
            sites: Vec::new(),
            neighbors: Vec::new(),
            first: Vec::new(),
            embedding: Vec::new(),
        }
    }

    pub(super) fn inputs(
        &mut self,
        board: &SpatialBoard,
        indices: &[[i64; 3]],
        features: &[[f32; FEATURES]],
        input: &mut Vec<f32>,
    ) {
        if !board.contexts.is_empty() {
            let stride = FEATURES + 4 * EMBEDDING;
            let offset = input.len();
            input.resize(offset + features.len() * stride, 0.);
            for actor in
                std::iter::once(-1).chain(board.contexts.iter().map(|c| c.actor_site as i64))
            {
                let selected: Vec<_> = indices
                    .iter()
                    .enumerate()
                    .filter(|(_, ix)| ix[0] == actor)
                    .map(|(i, _)| i)
                    .collect();
                if selected.is_empty() {
                    continue;
                }
                let context = board.contexts.iter().find(|c| c.actor_site as i64 == actor);
                let plain =
                    context
                        .map(|c| board.with_context(c))
                        .unwrap_or_else(|| SpatialBoard {
                            contexts: vec![],
                            ..board.clone()
                        });
                let ix: Vec<_> = selected.iter().map(|&i| indices[i]).collect();
                let x: Vec<_> = selected.iter().map(|&i| features[i]).collect();
                let mut rows = Vec::new();
                self.inputs(&plain, &ix, &x, &mut rows);
                for (i, row) in selected.into_iter().zip(rows.chunks_exact(stride)) {
                    input[offset + i * stride..offset + (i + 1) * stride].copy_from_slice(row);
                }
            }
            return;
        }
        let cells = board.height * board.width;
        if self.height != board.height
            || self.width != board.width
            || self.mask != board.values[..cells]
        {
            self.height = board.height;
            self.width = board.width;
            self.mask.clear();
            self.mask.extend_from_slice(&board.values[..cells]);
            self.sites.clear();
            self.sites
                .extend((0..cells).filter(|&site| board.values[site] == 1.));
            self.neighbors.clear();
            self.neighbors.extend(self.sites.iter().map(|&site| {
                KERNEL.map(|(dr, dq)| {
                    let row = (site / board.width) as i32 + dr;
                    let col = (site % board.width) as i32 + dq;
                    if row < 0 || col < 0 || row >= board.height as i32 || col >= board.width as i32
                    {
                        usize::MAX
                    } else {
                        row as usize * board.width + col as usize
                    }
                })
            }));
            // Invalid cells must be zero after a shape or mask change. With the
            // same geometry, kernels overwrite every valid cell on each call.
            self.first.resize(cells * EMBEDDING, 0.);
            self.first.fill(0.);
            self.embedding.resize(cells * EMBEDDING, 0.);
            self.embedding.fill(0.);
        }
        dispatch(
            self.arch,
            Kernel::<true> {
                layer: &self.layers[0],
                input: &board.values,
                output: &mut self.first,
                cells,
                sites: &self.sites,
                neighbors: &self.neighbors,
            },
        );
        dispatch(
            self.arch,
            Kernel::<false> {
                layer: &self.layers[1],
                input: &self.first,
                output: &mut self.embedding,
                cells,
                sites: &self.sites,
                neighbors: &self.neighbors,
            },
        );
        let mut pooled = [0.; EMBEDDING];
        for tile in self.embedding.chunks_exact(EMBEDDING) {
            for (sum, value) in pooled.iter_mut().zip(tile) {
                *sum += value;
            }
        }
        let count = self.sites.len() as f32;
        for sum in &mut pooled {
            *sum /= count;
        }
        input.reserve(features.len() * (FEATURES + 4 * EMBEDDING));
        for (features, tiles) in features.iter().zip(indices) {
            input.extend_from_slice(features);
            for &tile in tiles {
                if tile < 0 {
                    input.extend_from_slice(&[0.; EMBEDDING]);
                } else {
                    input.extend_from_slice(
                        &self.embedding[tile as usize * EMBEDDING..(tile as usize + 1) * EMBEDDING],
                    );
                }
            }
            input.extend_from_slice(&pooled);
        }
    }
}

#[inline]
fn dispatch<K: WithSimd>(arch: pulp::Arch, kernel: K) -> K::Output {
    // Host-specific builds select a concrete SIMD type before entering the
    // kernel. try_new folds to Some when the complete feature set is enabled.
    #[cfg(all(target_arch = "x86_64", target_feature = "avx512f"))]
    if let Some(simd) = pulp::x86::V4::try_new() {
        return Simd::vectorize(simd, kernel);
    }
    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    if let Some(simd) = pulp::x86::V3::try_new() {
        return Simd::vectorize(simd, kernel);
    }
    arch.dispatch(kernel)
}

struct Kernel<'a, const CHANNEL_MAJOR: bool> {
    layer: &'a ConvolutionLayer,
    input: &'a [f32],
    output: &'a mut [f32],
    cells: usize,
    sites: &'a [usize],
    neighbors: &'a [[usize; 7]],
}

impl<const CHANNEL_MAJOR: bool> WithSimd for Kernel<'_, CHANNEL_MAJOR> {
    type Output = ();

    #[inline(always)]
    fn with_simd<S: Simd>(self, simd: S) {
        // Exact accumulator counts let LLVM keep them in registers instead of
        // clearing sixteen vectors even on the one-vector AVX-512 path.
        match size_of::<S::f32s>() {
            4 => self.run::<S, 16>(simd),
            8 => self.run::<S, 8>(simd),
            16 => self.run::<S, 4>(simd),
            32 => self.run::<S, 2>(simd),
            64 => self.run::<S, 1>(simd),
            _ => unreachable!("unsupported SIMD width"),
        }
    }
}

impl<const CHANNEL_MAJOR: bool> Kernel<'_, CHANNEL_MAJOR> {
    #[inline(always)]
    fn run<S: Simd, const VECTORS: usize>(self, simd: S) {
        let lanes = size_of::<S::f32s>() / size_of::<f32>();
        assert_eq!(VECTORS * lanes, EMBEDDING);
        let zero = simd.splat_f32s(0.);
        let (bias, _) = S::as_simd_f32s(&self.layer.bias);
        for (&site, neighbors) in self.sites.iter().zip(self.neighbors) {
            let mut sums = [zero; VECTORS];
            for channel in 0..self.layer.channels {
                for (k, &neighbor) in neighbors.iter().enumerate() {
                    if neighbor == usize::MAX {
                        continue;
                    }
                    let value = self.input[if CHANNEL_MAJOR {
                        channel * self.cells + neighbor
                    } else {
                        neighbor * EMBEDDING + channel
                    }];
                    let value = simd.splat_f32s(value);
                    let offset = (channel * 7 + k) * EMBEDDING;
                    let (weights, _) =
                        S::as_simd_f32s(&self.layer.weights[offset..offset + EMBEDDING]);
                    for (sum, &weight) in sums.iter_mut().zip(weights) {
                        // Separate multiply/add retain the scalar accumulation order.
                        *sum = simd.add_f32s(*sum, simd.mul_f32s(value, weight));
                    }
                }
            }
            let a = site * EMBEDDING;
            let (output, _) = S::as_mut_simd_f32s(&mut self.output[a..a + EMBEDDING]);
            for ((out, sum), &bias) in output.iter_mut().zip(&sums).zip(bias) {
                *out = simd.max_f32s(simd.add_f32s(*sum, bias), zero);
            }
        }
    }
}
