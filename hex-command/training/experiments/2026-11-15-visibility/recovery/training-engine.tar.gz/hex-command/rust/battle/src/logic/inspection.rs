//! Immutable browser query publication; no work is added to simulation turns.
use super::battle::LiveBattle;
use crate::data::presentation::ConditionContext;
use crate::logic::conditions::LiveContext;
use crate::logic::event_queries::{EventFacts, reference_site};
use crate::{data::*, model::*};

fn campaign_objectives(game: &LiveBattle<'_>) -> Option<CampaignObjectives> {
    game.story.campaign.as_ref()?;
    let mission = game.story.mission.as_ref()?;
    let leader_alive = EventFacts::new(game).campaign_leader_survives("player");
    let survival = |label: String, alive: bool| ObjectiveStatus {
        active_tiles: vec![],
        visible: true,
        available: true,
        progress: Progress {
            label,
            current: u32::from(game.runtime.winner.is_some() && alive),
            total: 1,
            done: game.runtime.winner.is_some() && alive,
            tiles: vec![],
        },
        failed: !alive,
    };
    let mut protected = vec![survival("Keep your leader alive.".into(), leader_alive)];
    for name in &mission.required_companions {
        let alive = EventFacts::new(game).campaign_companion_survives("player", name);
        protected.push(survival(
            format!("Keep {} alive.", character_name(game, name).unwrap_or(name)),
            alive,
        ));
    }
    let status = |optional| {
        mission
            .scripted_events
            .iter()
            .filter(|e| {
                e.objective
                    .as_ref()
                    .is_some_and(|o| o.faction == "player" && o.optional == optional)
            })
            .map(|e| scripted_objective_status(game, e))
            .collect()
    };
    Some(CampaignObjectives {
        goals: status(false),
        optional: status(true),
        survival: protected,
    })
}

pub(crate) fn inspect_board(game: &super::BattlePosition<'_>) -> BoardInspection {
    BoardInspection {
        costs: game
            .rules
            .units
            .iter()
            .map(|rule| {
                (
                    rule.id.clone(),
                    game.rules
                        .terrain_names
                        .iter()
                        .cloned()
                        .zip(rule.costs.iter().copied())
                        .collect(),
                )
            })
            .collect(),
        neighbors: game
            .board
            .ids
            .iter()
            .enumerate()
            .map(|(index, id)| {
                (
                    id.to_string(),
                    game.runtime.board.adjacent[index]
                        .iter()
                        .map(|&next| game.runtime.board.ids[next].clone())
                        .collect(),
                )
            })
            .collect(),
    }
}

pub(crate) fn inspect(game: &LiveBattle<'_>, revision: u32) -> BattleInspection {
    let units = game
        .units
        .iter()
        .map(|unit| {
            let mut attacks = Vec::new();
            for target in &game.runtime.units {
                for weapon in game.attack_options(unit, target, unit.tile) {
                    let attack = game.weapon(unit, weapon).clone();
                    let (damage, retaliation, response) =
                        game.preview(unit, target, weapon, unit.tile);
                    let forecast = game.exchange(unit, target, weapon, unit.tile);
                    let health = |side| HpForecast {
                        minimum: forecast.hp_minimum[side],
                        maximum: forecast.hp_maximum[side],
                        expected: forecast.hp_expected[side],
                    };
                    let response = response.map(|index| game.weapon(target, index).clone());
                    let retaliation_detail = response
                        .as_ref()
                        .map(|r| game.damage_detail(r, unit, unit.tile));
                    attacks.push(AttackDetails {
                        attacker_health: health(0),
                        defender_health: health(1),
                        kill_chance: forecast.death[1],
                        death_chance: forecast.death[0],
                        retaliation_min: forecast.minimum[1],
                        retaliation_max: forecast.maximum[1],
                        healing: forecast.healing[0].round() as i32,
                        retaliation_healing: forecast.healing[1].round() as i32,
                        thorn_damage: forecast.reflection.round() as i32,
                        recommended: false,
                        target: format!("u{}", target.id),
                        damage,
                        retaliation,
                        damage_detail: game.damage_detail(&attack, target, target.tile),
                        attack: game.source_weapon(&attack).clone(),
                        response: response
                            .as_ref()
                            .map(|attack| game.source_weapon(attack).clone()),
                        retaliation_detail,
                    });
                }
            }
            UnitActions {
                name: game
                    .name(unit.character)
                    .and_then(|id| character_name(game, id))
                    .map(str::to_owned),
                faction: game.unit_faction_view(unit),
                unit: format!("u{}", unit.id),
                reachable: game
                    .observed_reachable(unit)
                    .iter()
                    .copied()
                    .map(|(tile, cost)| ReachableTile {
                        tile: TileId(game.runtime.board.ids[tile].clone()),
                        cost,
                    })
                    .collect(),
                attacks,
                promotions: game
                    .promotion_options(unit)
                    .into_iter()
                    .map(|kind| game.rules.units[kind].id.clone())
                    .collect(),
                recruitment: game
                    .recruitment_options_for(unit)
                    .into_iter()
                    .map(|kind| {
                        (
                            game.rules.units[kind].id.clone(),
                            game.placement_tiles(unit, kind, true)
                                .into_iter()
                                .map(|tile| game.runtime.board.ids[tile].clone())
                                .collect(),
                        )
                    })
                    .collect(),
            }
        })
        .collect();
    BattleInspection {
        story: LiveContext::new(&game, None, None).resolved_story(),
        speakers: game
            .story
            .campaign
            .as_ref()
            .map(|state| {
                state
                    .dialogue
                    .iter()
                    .map(|line| {
                        line.character
                            .as_deref()
                            .and_then(|id| character_name(game, id))
                            .unwrap_or(&line.speaker)
                            .to_owned()
                    })
                    .collect()
            })
            .unwrap_or_default(),
        objectives: campaign_objectives(game),
        revision,
        units,
        recruitment: game
            .gold
            .keys()
            .map(|id| {
                (
                    id.clone(),
                    game.recruitment_options_for_faction(id)
                        .into_iter()
                        .map(|kind| game.rules.units[kind].id.clone())
                        .collect(),
                )
            })
            .collect(),
        recruitment_prices: game
            .gold
            .keys()
            .map(|id| {
                (
                    id.clone(),
                    game.recruitment_options_for_faction(id)
                        .into_iter()
                        .map(|kind| {
                            (
                                game.rules.units[kind].id.clone(),
                                game.recruit_cost_for_faction(id, kind),
                            )
                        })
                        .collect(),
                )
            })
            .collect(),
        income: Gold(std::sync::Arc::new(
            game.runtime
                .gold
                .keys()
                .map(|id| (id.clone(), game.faction_income(id)))
                .collect(),
        )),
    }
}

impl super::BattlePosition<'_> {
    fn damage_detail(&self, attack: &WeaponRules, defender: &Unit, tile: usize) -> DamageDetail {
        let rule = &self.rules.units[defender.kind];
        let modifier = rule.damage_modifiers.get(attack.damage_type)
            + self.equipment_modifier(defender, attack.damage_type);
        let environment = rule.environment[self.runtime.terrain[tile]][attack.category.index()]
            [attack.damage_type.index()];
        let distribution = super::damage::distribution(attack, modifier + environment);
        DamageDetail {
            roll_min: attack.damage - attack.spread,
            roll_max: attack.damage + attack.spread,
            minimum: distribution.min,
            maximum: distribution.max,
            expected: distribution.mean,
            probabilities: distribution.probabilities.clone(),
            count: attack.count,
            total: distribution.mean.round() as i32,
            base: attack.damage,
            damage_type: attack.damage_type,
            modifier,
            modified: attack.damage + modifier,
            protection: (-environment).max(0),
            exposure: environment.max(0),
            terrain: self.rules.terrain_names[self.runtime.terrain[tile]].clone(),
            damage: (attack.damage + modifier + environment).max(0),
        }
    }
}

fn character_name<'a>(game: &'a LiveBattle<'_>, id: &str) -> Option<&'a str> {
    game.story
        .campaign_definition
        .as_ref()
        .or_else(|| game.rules.campaign_for_map(&game.runtime.map_id))
        .and_then(|campaign| campaign.character(id))
        .map(|c| c.name.as_str())
}

#[cfg(not(target_arch = "wasm32"))]
pub(crate) fn event_goal_progress(game: &LiveBattle<'_>) -> Vec<Progress> {
    game.story.mission.as_ref().map_or_else(Vec::new, |m| {
        m.scripted_events
            .iter()
            .filter(|e| {
                e.objective
                    .as_ref()
                    .is_some_and(|o| o.faction == "player" && !o.optional)
            })
            .map(|e| EventFacts::new(game).objective_progress(e))
            .collect()
    })
}

fn scripted_objective_status(game: &LiveBattle<'_>, event: &ScriptEvent) -> ObjectiveStatus {
    let objective = event.objective.as_ref().unwrap();
    let state = game.story.scripts.as_deref().unwrap();
    let facts = EventFacts::new(game);
    let failed = state.failed.iter().any(|id| id == event.objective_id());
    let progress = facts.objective_progress(event);
    let done = progress.done;
    let available = facts.objective_available(event);
    let visible = state.revealed.iter().any(|id| id == event.objective_id());
    // Markers are authored UI data, never inferred from AI movement or completion regions.
    let markers = objective
        .player_marker
        .as_ref()
        .map_or_else(Vec::new, |marker| {
            let destinations: Vec<Hex> = if let Some(select) = &marker.units {
                game.runtime
                    .units
                    .iter()
                    .filter(|unit| {
                        EventFacts::for_faction(game, &objective.faction)
                            .script_unit_matches(select, unit)
                    })
                    .filter(|unit| {
                        marker.visible_in_fog
                            || game.unit_visible_to(&objective.faction, unit, None)
                    })
                    .map(|unit| game.position.runtime.board.ids[unit.tile].clone())
                    .collect()
            } else {
                marker
                    .tiles
                    .iter()
                    .map(|name| {
                        game.position.runtime.board.ids[reference_site(&game.board, name)].clone()
                    })
                    .collect()
            };
            destinations
                .into_iter()
                .filter(|tile| {
                    marker.visible_in_fog
                        || super::conditions::LiveContext::for_faction(
                            game,
                            &objective.faction,
                            None,
                        )
                        .visible_at(
                            game.position.runtime.board.positions[game.site(tile)],
                            &objective.faction,
                        )
                })
                .collect()
        });
    ObjectiveStatus {
        active_tiles: if !done
            && !failed
            && visible
            && available
            && game.position.runtime.winner.is_none()
        {
            markers
        } else {
            vec![]
        },
        visible,
        available,
        failed,
        progress,
    }
}
