//! Author-only ability expansion; excluded from baked browser runtime.
use super::AbilityInfo;
use crate::data::{ContentError, JsonBundle};
use serde::Deserialize;
use serde_json::{Map, Value};
use std::collections::{HashMap, HashSet};
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct AbilityDefinition {
    id: String,
    name: String,
    description: String,
    #[serde(default)]
    includes: Vec<String>,
    rules: Map<String, Value>,
}
#[derive(Deserialize)]
#[serde(untagged)]
enum AbilityReference {
    Name(String),
    Section { id: String, section: String },
}
impl AbilityReference {
    fn id(&self) -> &str {
        match self {
            Self::Name(id) | Self::Section { id, .. } => id,
        }
    }
}
struct AbilityRegistry {
    definitions: HashMap<String, (String, AbilityDefinition)>,
    resolved: HashMap<String, Map<String, Value>>,
}
impl AbilityRegistry {
    fn definition(
        &mut self,
        id: &str,
        stack: &mut Vec<String>,
        path: &str,
    ) -> Result<Map<String, Value>, ContentError> {
        if stack.iter().any(|known| known == id) {
            return Err(ContentError::new(
                path,
                format!("cyclic ability reference: {} -> {id}", stack.join(" -> ")),
            ));
        }
        if let Some(rules) = self.resolved.get(id) {
            return Ok(rules.clone());
        }
        let (source, definition) = self
            .definitions
            .get(id)
            .ok_or_else(|| ContentError::new(path, format!("unknown ability {id}")))?;
        let source = source.clone();
        let includes = definition.includes.clone();
        let rules = definition.rules.clone();
        stack.push(id.into());
        let mut merged = Map::new();
        let mut seen = HashSet::new();
        for parent in includes {
            if !seen.insert(parent.clone()) {
                return Err(ContentError::new(
                    &source,
                    format!("duplicate included ability {parent}"),
                ));
            }
            let inherited = self.definition(&parent, stack, &source)?;
            merge(&mut merged, inherited, false, &source)?;
        }
        merge(&mut merged, rules, true, &source)?;
        let mut value = Value::Object(merged);
        self.expand(&mut value, stack, &source)?;
        stack.pop();
        let Value::Object(rules) = value else {
            unreachable!()
        };
        self.resolved.insert(id.into(), rules.clone());
        Ok(rules)
    }
    fn expand(
        &mut self,
        value: &mut Value,
        stack: &mut Vec<String>,
        path: &str,
    ) -> Result<(), ContentError> {
        match value {
            Value::Object(object) => {
                if let Some(references) = object.remove("abilities") {
                    let ids: Vec<AbilityReference> =
                        serde_json::from_value(references).map_err(|e| {
                            ContentError::new(
                                path,
                                format!("abilities must be an array of names: {e}"),
                            )
                        })?;
                    let mut seen = HashSet::new();
                    let mut combined = Map::new();
                    for reference in ids {
                        let id = reference.id();
                        let identity = match &reference {
                            AbilityReference::Name(_) => id.to_owned(),
                            AbilityReference::Section { section, .. } => format!("{id}:{section}"),
                        };
                        if !seen.insert(identity) {
                            return Err(ContentError::new(path, format!("duplicate ability {id}")));
                        }
                        let rules = self.definition(id, stack, path)?;
                        let rules = match &reference {
                            AbilityReference::Name(_) => rules,
                            AbilityReference::Section { section, .. } => rules
                                .get(section)
                                .and_then(Value::as_object)
                                .cloned()
                                .ok_or_else(|| {
                                    ContentError::new(
                                        path,
                                        format!("ability {id} has no rule section {section}"),
                                    )
                                })?,
                        };
                        merge(&mut combined, rules, false, path)?;
                    }
                    merge(&mut combined, std::mem::take(object), true, path)?;
                    *object = combined;
                }
                for value in object.values_mut() {
                    self.expand(value, stack, path)?;
                }
            }
            Value::Array(values) => {
                for value in values {
                    self.expand(value, stack, path)?;
                }
            }
            _ => {}
        }
        Ok(())
    }
}
fn merge(
    target: &mut Map<String, Value>,
    source: Map<String, Value>,
    overrides: bool,
    path: &str,
) -> Result<(), ContentError> {
    for (key, value) in source {
        match (target.get_mut(&key), value) {
            (Some(Value::Object(old)), Value::Object(new)) => merge(old, new, overrides, path)?,
            (Some(Value::Array(old)), Value::Array(new)) => {
                for value in new {
                    if !old.contains(&value) {
                        old.push(value);
                    }
                }
            }
            (Some(old), new) if *old == new => {}
            (Some(old), new) if overrides => *old = new,
            (Some(_), _) => {
                return Err(ContentError::new(
                    path,
                    format!("conflicting ability field {key}; resolve it explicitly"),
                ));
            }
            (None, new) => {
                target.insert(key, new);
            }
        }
    }
    Ok(())
}
fn references(value: &Value, ids: &mut Vec<String>) {
    match value {
        Value::Object(object) => {
            if let Some(Value::Array(names)) = object.get("abilities") {
                for name in names.iter().filter_map(|value| {
                    value
                        .as_str()
                        .or_else(|| value.get("id").and_then(Value::as_str))
                }) {
                    if !ids.iter().any(|id| id == name) {
                        ids.push(name.into());
                    }
                }
            }
            for value in object.values() {
                references(value, ids);
            }
        }
        Value::Array(values) => {
            for value in values {
                references(value, ids);
            }
        }
        _ => {}
    }
}
pub(crate) fn resolve_bundle(
    bundle: &JsonBundle,
    paths: &[String],
    units: &[String],
) -> Result<(JsonBundle, Vec<AbilityInfo>), ContentError> {
    let mut registry = AbilityRegistry {
        definitions: HashMap::new(),
        resolved: HashMap::new(),
    };
    let mut info = Vec::new();
    for path in paths {
        let definition: AbilityDefinition = serde_json::from_str(
            bundle
                .get(path)
                .ok_or_else(|| ContentError::new(path, "missing ability document"))?,
        )
        .map_err(|e| ContentError::new(path, e.to_string()))?;
        crate::data::catalog::identifier(&definition.id, "ability")
            .map_err(|e| ContentError::new(path, e.to_string()))?;
        if definition.name.trim().is_empty()
            || definition.description.trim().is_empty()
            || definition.rules.is_empty() && definition.includes.is_empty()
        {
            return Err(ContentError::new(
                path,
                "ability needs a name, description and rules or includes",
            ));
        }
        info.push(AbilityInfo {
            id: definition.id.clone(),
            name: definition.name.clone(),
            description: definition.description.clone(),
            perception: None,
        });
        if registry
            .definitions
            .insert(definition.id.clone(), (path.clone(), definition))
            .is_some()
        {
            return Err(ContentError::new(path, "duplicate ability ID"));
        }
    }
    for id in registry.definitions.keys().cloned().collect::<Vec<_>>() {
        registry.definition(&id, &mut Vec::new(), "abilities")?;
    }
    for ability in &mut info {
        if let Some(profile) = registry.resolved[&ability.id].get("perception") {
            let profile: crate::data::UnitPerception = serde_json::from_value(profile.clone())
                .map_err(|e| {
                    ContentError::new(&registry.definitions[&ability.id].0, e.to_string())
                })?;
            crate::data::validate_unit_perception(&profile.concealment, &profile.penetrates)
                .map_err(|e| ContentError::new(&registry.definitions[&ability.id].0, e))?;
            ability.perception = Some(profile);
        }
    }
    let mut resolved = bundle.clone();
    for (path, source) in bundle {
        if path == "manifest.json" || paths.contains(path) {
            continue;
        }
        let mut value: Value =
            serde_json::from_str(source).map_err(|e| ContentError::new(path, e.to_string()))?;
        let mut ids = Vec::new();
        if units.contains(path) && value.get("abilityIds").is_some() {
            return Err(ContentError::new(
                path,
                "abilityIds is resolved metadata; author abilities instead",
            ));
        }
        if units.contains(path) {
            references(&value, &mut ids);
        }
        registry.expand(&mut value, &mut Vec::new(), path)?;
        if units.contains(path) && !ids.is_empty() {
            value
                .as_object_mut()
                .unwrap()
                .insert("abilityIds".into(), serde_json::to_value(ids).unwrap());
        }
        resolved.insert(path.clone(), value.to_string());
    }
    Ok((resolved, info))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn fragments_resolve_sections_overrides_and_reject_bad_references() {
        let mut bundle = JsonBundle::from([
            ("cloak.json".into(), r#"{"id":"cloak","name":"Cloak","description":"Cover","rules":{"perception":{"range":4,"penetrates":["darkness"]}}}"#.into()),
            ("unit.json".into(), r#"{"abilities":["cloak"],"perception":{"range":7},"effect":{"abilities":[{"id":"cloak","section":"perception"}]}}"#.into()),
        ]);
        let paths = vec!["cloak.json".into()];
        let units = vec!["unit.json".into()];
        let (expanded, info) = resolve_bundle(&bundle, &paths, &units).unwrap();
        let unit: Value = serde_json::from_str(&expanded["unit.json"]).unwrap();
        assert_eq!(unit["perception"]["range"], 7);
        assert_eq!(unit["effect"]["range"], 4);
        assert_eq!(unit["abilityIds"], serde_json::json!(["cloak"]));
        assert_eq!(info[0].name, "Cloak");
        assert!(bundle["unit.json"].contains("abilities"));
        bundle.insert("unit.json".into(), r#"{"abilities":["missing"]}"#.into());
        let error = resolve_bundle(&bundle, &paths, &units).unwrap_err();
        assert_eq!(error.path, "unit.json");
        assert!(error.message.contains("unknown ability"));
        bundle.insert("cloak.json".into(), r#"{"id":"cloak","name":"Cloak","description":"Cover","includes":["cloak"],"rules":{}}"#.into());
        assert!(
            resolve_bundle(&bundle, &paths, &units)
                .unwrap_err()
                .message
                .contains("cyclic")
        );
    }
}
