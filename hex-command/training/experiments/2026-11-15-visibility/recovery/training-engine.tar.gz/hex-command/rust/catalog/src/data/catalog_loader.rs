//! Authoring, validation and inheritance resolution, excluded from the default browser build.
use super::*;
use serde::{Deserialize, de::DeserializeOwned};
use sha2::{Digest, Sha256};
use std::{
    collections::{HashMap, HashSet},
    path::{Component, Path},
};
#[path = "catalog_documents.rs"]
mod documents;
#[cfg(feature = "wasm")]
include!(concat!(env!("OUT_DIR"), "/catalog_documents.rs"));
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Manifest {
    schema_version: u32,
    terrain: String,
    concealment_kinds: String,
    races: Vec<String>,
    units: Vec<String>,
    #[serde(default)]
    abilities: Vec<String>,
    items: Vec<String>,
    scenarios: Vec<String>,
    campaigns: Vec<String>,
    simulation: SimulationPaths,
    #[serde(default)]
    recruitment: Option<String>,
}
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct SimulationPaths {
    rosters: String,
    arena: String,
    campaign: String,
    rl: String,
}
impl EnvironmentalModifiers {
    fn value(&self, category: usize, damage: usize) -> i32 {
        [self.melee, self.ranged][category] + [self.blade, self.pierce, self.impact][damage]
    }
}
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct UnitSpecification {
    #[serde(default)]
    perception: UnitPerception,
    #[serde(default)]
    ability_ids: Vec<String>,
    #[serde(default)]
    sight_modifiers: SightModifiers,
    id: String,
    name: String,
    hp: i32,
    r#move: usize,
    cost: i32,
    attacks: Vec<Weapon>,
    damage_modifiers: DamageModifiers,
    race: Race,
    role: UnitRole,
    #[serde(default)]
    terrain_modifiers: HashMap<TerrainRole, TerrainModifier>,
    #[serde(default)]
    healing: i32,
    #[serde(default)]
    thorns: i32,
    #[serde(default)]
    thorn_aura: i32,
    level: u32,
    family: Family,
    experience_needed: u32,
    advances_to: Vec<String>,
    ability: String,
    description: String,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct CampaignFile {
    human: bool,
    id: String,
    name: String,
    tagline: String,
    description: String,
    #[serde(rename = "shortDescription")]
    short_description: String,
    race: Race,
    leader: String,
    stages: Vec<String>,
    characters: Vec<Character>,
    ending: Vec<Speech>,
}
#[derive(Deserialize)]
struct StageFile {
    id: String,
    state: InitialState,
    #[serde(flatten)]
    mission: Mission,
}

/// Authored initial placements derive omitted runtime defaults from unit rules.
#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct InitialUnit {
    #[serde(default)]
    perception_effects: Vec<PerceptionEffect>,
    #[serde(default)]
    items: Vec<Item>,
    faction: Option<String>,
    ai_group: Option<String>,
    id: Option<String>,
    r#type: String,
    tile: Hex,
    hp: Option<i32>,
    character: Option<String>,
    role: Option<Role>,
}
fn initial_round() -> u32 {
    1
}
fn initial_turn() -> TurnPhase {
    TurnPhase::Player
}
#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct InitialState {
    vision_groups: Vec<VisionGroupState>,
    #[serde(default)]
    factions: Vec<Faction>,
    map_id: String,
    map_revision: u32,
    cols: i32,
    rows: i32,
    gold: Gold,
    tiles: Vec<Tile>,
    units: Vec<InitialUnit>,
}
impl InitialState {
    fn resolve(
        self,
        rules: &[UnitRule],
        types: &HashMap<String, usize>,
        path: &str,
    ) -> Result<State, ContentError> {
        let mut units = Vec::with_capacity(self.units.len());
        let mut next_id = 1;
        for (index, unit) in self.units.into_iter().enumerate() {
            reference(&unit.r#type, types, path)?;
            let rule = &rules[types[&unit.r#type]];
            let hp = unit.hp.unwrap_or(rule.hp);
            if hp <= 0 || hp > rule.hp {
                return Err(ContentError::new(
                    path,
                    format!("invalid initial HP for {}", unit.r#type),
                ));
            }
            let id = unit.id.unwrap_or_else(|| format!("u{}", index + 1));
            let number = id
                .strip_prefix('u')
                .and_then(|id| id.parse::<u32>().ok())
                .filter(|id| *id > 0)
                .ok_or_else(|| {
                    ContentError::new(path, format!("invalid initial unit identifier {id}"))
                })?;
            next_id = next_id.max(
                number
                    .checked_add(1)
                    .ok_or_else(|| ContentError::new(path, "initial unit identifier overflow"))?,
            );
            validate_equipment(&unit.items, &rule.attacks, path)?;
            let tile = self
                .tiles
                .iter()
                .find(|t| t.hex() == unit.tile)
                .ok_or_else(|| ContentError::new(path, "initial unit is outside its board"))?
                .hex();
            units.push(PublicUnit {
                revealed_to: vec![],
                perception_effects: unit.perception_effects,
                faction: unit
                    .faction
                    .ok_or_else(|| ContentError::new(path, "unit requires an explicit faction"))?,
                items: unit.items,
                ai_group: unit.ai_group,
                id,
                r#type: unit.r#type,
                tile,
                hp,
                moved: false,
                attack_spent: false,
                experience: Some(0),
                character: unit.character,
                role: unit.role,
                retreating: None,
                rebuilding: None,
            });
        }
        validate_perception(&self.vision_groups, &self.factions, &self.tiles, &units)
            .map_err(|message| ContentError::new(path, message))?;
        validate_factions(&self.factions, &units)
            .map_err(|message| ContentError::new(path, message))?;
        for faction in &self.factions {
            if let Some(transfer) = &faction.transfer {
                transfer
                    .when
                    .validate_references(types, &self.factions)
                    .map_err(|message| ContentError::new(path, message))?;
            }
        }
        validate_economy(&self.factions, &self.gold, &self.tiles, types)
            .map_err(|message| ContentError::new(path, message))?;
        Ok(State {
            vision_groups: self.vision_groups,
            factions: self.factions,
            ground_items: vec![],
            condition_memory: vec![],
            armies: None,
            map_id: self.map_id,
            map_revision: self.map_revision,
            cols: self.cols,
            rows: self.rows,
            round: initial_round(),
            turn: initial_turn(),
            gold: self.gold,
            winner: None,
            next_id,
            log: vec!["Capture villages for gold. Defeat the enemy commander.".to_owned()],
            tiles: self.tiles,
            units,
            campaign: None,
            combat_rng: 0x6d2b79f5,
            last_combat: None,
        })
    }
}

fn parse<T: DeserializeOwned>(bundle: &JsonBundle, path: &str) -> Result<T, ContentError> {
    checked_path(path)?;
    let source = bundle
        .get(path)
        .ok_or_else(|| ContentError::new(path, "missing catalog document"))?;
    serde_json::from_str(source).map_err(|error| ContentError::new(path, error.to_string()))
}
fn checked_path(path: &str) -> Result<(), ContentError> {
    if path.is_empty()
        || Path::new(path)
            .components()
            .any(|part| !matches!(part, Component::Normal(_)))
    {
        return Err(ContentError::new(
            path,
            "catalog paths must be relative without traversal",
        ));
    }
    Ok(())
}
fn reference(id: &str, types: &HashMap<String, usize>, path: &str) -> Result<(), ContentError> {
    if !types.contains_key(id) {
        return Err(ContentError::new(path, format!("unknown unit {id}")));
    }
    Ok(())
}

impl Rules {
    /// Native data root never depends on the process working directory.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn load() -> Result<Self, ContentError> {
        let root = std::env::var_os("HEX_COMMAND_DATA_ROOT")
            .map(std::path::PathBuf::from)
            .unwrap_or_else(|| Path::new(env!("CARGO_MANIFEST_DIR")).join("../data"));
        Self::load_from(root)
    }
    /// Load the compiled WASM catalog, or report that an explicit bundle is needed.
    #[cfg(target_arch = "wasm32")]
    pub fn load() -> Result<Self, ContentError> {
        #[cfg(feature = "wasm")]
        {
            Self::embedded()
        }
        #[cfg(not(feature = "wasm"))]
        {
            Err(ContentError::new(
                "manifest.json",
                "WebAssembly callers must supply a JSON bundle",
            ))
        }
    }
    /// Read and validate a native catalog rooted at an explicit filesystem path.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn load_from(root: impl AsRef<Path>) -> Result<Self, ContentError> {
        let root = root.as_ref();
        documents::collect_bundle(|path| {
            checked_path(path)?;
            std::fs::read_to_string(root.join(path))
                .map_err(|error| ContentError::new(path, error.to_string()))
        })
        .and_then(|bundle| Self::from_json_bundle(&bundle))
    }
    /// Load the bundled catalog for WASM deployment and embedding checks.
    #[cfg(feature = "wasm")]
    pub fn embedded() -> Result<Self, ContentError> {
        Self::from_json_bundle(&embedded_bundle())
    }
    /// Validate named documents and resolve inheritance without filesystem access.
    pub fn from_json_bundle(bundle: &JsonBundle) -> Result<Self, ContentError> {
        let manifest: Manifest = parse(bundle, "manifest.json")?;
        if manifest.schema_version != 3 {
            return Err(ContentError::new(
                "manifest.json",
                "unsupported schemaVersion",
            ));
        }
        let fingerprint = content_fingerprint(bundle);
        let (resolved, abilities) =
            super::abilities::resolve_bundle(bundle, &manifest.abilities, &manifest.units)?;
        let bundle = &resolved;
        let definitions: Vec<ConcealmentKindDefinition> =
            parse(bundle, &manifest.concealment_kinds)?;
        let mut seen = ConcealmentMask::default();
        let mut concealment_visuals = ConcealmentMask::default();
        for definition in definitions {
            if seen.contains(definition.id) {
                return Err(ContentError::new(
                    &manifest.concealment_kinds,
                    "duplicate concealment kind",
                ));
            }
            seen.insert(definition.id);
            if matches!(definition.unit_appearance, ConcealmentVisual::Concealment) {
                concealment_visuals.insert(definition.id);
            }
        }
        if ConcealmentKind::ALL
            .into_iter()
            .any(|kind| !seen.contains(kind))
        {
            return Err(ContentError::new(
                &manifest.concealment_kinds,
                "missing concealment kind",
            ));
        }
        let terrain: Vec<TerrainDefinition> = parse(bundle, &manifest.terrain)?;
        unique(manifest.items.iter().map(String::as_str), "manifest.json")?;
        let mut items = HashMap::new();
        for path in &manifest.items {
            let item: Item = parse(bundle, path)?;
            item.validate(path)?;
            if items.insert(item.id.clone(), item).is_some() {
                return Err(ContentError::new(path, "duplicate item ID"));
            }
        }

        unique(manifest.races.iter().map(String::as_str), "manifest.json")?;
        let races: Vec<(String, RaceDefinition)> = manifest
            .races
            .iter()
            .map(|path| parse(bundle, path).map(|race| (path.clone(), race)))
            .collect::<Result<_, _>>()?;
        unique(manifest.units.iter().map(String::as_str), "manifest.json")?;
        let specs: Vec<(String, UnitSpecification)> = manifest
            .units
            .iter()
            .map(|path| parse(bundle, path).map(|spec| (path.clone(), spec)))
            .collect::<Result<_, _>>()?;
        if terrain.is_empty() || races.is_empty() || specs.is_empty() {
            return Err(ContentError::new(
                "manifest.json",
                "terrain, races and units must be nonempty",
            ));
        }
        unique(terrain.iter().map(|t| t.id.as_str()), &manifest.terrain)?;
        let mut seen_races = HashSet::new();
        for (path, race) in &races {
            if !seen_races.insert(race.id) {
                return Err(ContentError::new(
                    path,
                    format!("duplicate race {}", race.id),
                ));
            }
        }
        let mut seen_units = HashSet::new();
        for (path, spec) in &specs {
            if !seen_units.insert(&spec.id) {
                return Err(ContentError::new(
                    path,
                    format!("duplicate identifier {}", spec.id),
                ));
            }
        }
        let terrain_names: Vec<String> = terrain.iter().map(|t| t.id.as_str().to_owned()).collect();
        let terrains: HashMap<String, usize> = terrain_names
            .iter()
            .enumerate()
            .map(|(i, id)| (id.clone(), i))
            .collect();
        let types: HashMap<String, usize> = specs
            .iter()
            .enumerate()
            .map(|(i, (_, u))| (u.id.clone(), i))
            .collect();
        let race_by_id: HashMap<Race, &RaceDefinition> =
            races.iter().map(|(_, r)| (r.id, r)).collect();
        let validate_modifiers = |modifiers: &HashMap<TerrainRole, TerrainModifier>,
                                  path: &str|
         -> Result<(), ContentError> {
            for id in modifiers.keys() {
                if !terrain.iter().any(|definition| definition.role == *id) {
                    return Err(ContentError::new(
                        path,
                        format!("unused terrain role {id:?}"),
                    ));
                }
            }
            Ok(())
        };
        for t in &terrain {
            if t.name.is_empty() || t.description.is_empty() || t.cost == 0 {
                return Err(ContentError::new(
                    &manifest.terrain,
                    "terrain requires name, description and positive cost",
                ));
            }
        }
        for (path, race) in &races {
            if race.name.is_empty() {
                return Err(ContentError::new(path, "race name is required"));
            }
            validate_modifiers(&race.terrain_modifiers, path)?;
        }
        let mut units = Vec::with_capacity(specs.len());
        for (path, spec) in specs {
            identifier(&spec.id, &path)?;
            let race = race_by_id
                .get(&spec.race)
                .ok_or_else(|| ContentError::new(&path, format!("unknown race {}", spec.race)))?;
            if spec.name.is_empty()
                || spec.ability.is_empty()
                || spec.description.is_empty()
                || spec.hp <= 0
                || spec.r#move == 0
                || spec.cost < 0
                || spec.level == 0
                || spec.healing < 0
                || spec.thorns < 0
                || spec.thorn_aura < 0
            {
                return Err(ContentError::new(
                    &path,
                    format!("invalid required stats for {}", spec.id),
                ));
            }
            unique(spec.attacks.iter().map(|w| w.id.as_str()), &path)?;
            for attack in &spec.attacks {
                attack.validate(&path)?;
            }
            for next in &spec.advances_to {
                reference(next, &types, &path)?;
            }
            validate_modifiers(&spec.terrain_modifiers, &path)?;
            let mut costs = Vec::new();
            let mut environment = Vec::new();
            for t in &terrain {
                let inherited = race.terrain_modifiers.get(&t.role);
                let individual = spec.terrain_modifiers.get(&t.role);
                let passable = individual
                    .and_then(|m| m.passable)
                    .or_else(|| inherited.and_then(|m| m.passable))
                    .unwrap_or(t.passable);
                let cost = (i32::from(t.cost)
                    + inherited.map_or(0, |m| m.cost)
                    + individual.map_or(0, |m| m.cost))
                .max(1);
                costs.push(if passable {
                    Some(
                        u16::try_from(cost)
                            .map_err(|_| ContentError::new(&path, "movement cost overflows u16"))?,
                    )
                } else {
                    None
                });
                let mut modifiers = [[0; 3]; 2];
                for (category, row) in modifiers.iter_mut().enumerate() {
                    for (damage, value) in row.iter_mut().enumerate() {
                        *value = t.damage_modifiers.value(category, damage)
                            + inherited.map_or(0, |m| m.damage_modifiers.value(category, damage))
                            + individual.map_or(0, |m| m.damage_modifiers.value(category, damage));
                    }
                }
                environment.push(modifiers);
            }
            validate_unit_perception(&spec.perception.concealment, &spec.perception.penetrates)
                .map_err(|e| ContentError::new(&path, e))?;
            units.push(UnitRule {
                perception: spec.perception,
                ability_ids: spec.ability_ids,
                sight_modifiers: spec.sight_modifiers,
                id: spec.id,
                name: spec.name,
                ability: spec.ability,
                description: spec.description,
                hp: spec.hp,
                r#move: spec.r#move,
                damage: spec.attacks.first().map_or(0, |attack| attack.damage),
                range: spec.attacks.iter().map(|w| w.range).max().unwrap_or(0),
                cost: spec.cost,
                attacks: spec.attacks,
                damage_modifiers: DamageModifiers {
                    blade: race.damage_modifiers.blade + spec.damage_modifiers.blade,
                    pierce: race.damage_modifiers.pierce + spec.damage_modifiers.pierce,
                    impact: race.damage_modifiers.impact + spec.damage_modifiers.impact,
                },
                race: spec.race,
                role: spec.role,
                healing: spec.healing,
                thorns: spec.thorns,
                thorn_aura: spec.thorn_aura,
                level: spec.level,
                family: spec.family,
                experience_needed: Some(spec.experience_needed),
                advances_to: spec.advances_to,
                costs,
                environment,
            });
        }
        let mut map_definitions = Vec::new();
        let mut maps = HashMap::new();
        let mut scenario_characters = HashMap::new();
        let mut campaigns = HashMap::new();
        let mut used_paths = HashSet::new();
        for path in &manifest.scenarios {
            if !used_paths.insert(path.clone()) {
                return Err(ContentError::new(path, "duplicate catalog path"));
            }
            let (initial, roster_path, human, characters) =
                documents::scenario(bundle, path, &items)?;
            let state = initial.resolve(&units, &types, &roster_path)?;
            scenario_characters.insert((state.map_id.clone(), state.map_revision), characters);
            map_definitions.push(documents::map_metadata(bundle, path, &state, None, human)?);
            insert_map(&mut maps, state, &terrains, &types, path)?;
        }
        for path in &manifest.campaigns {
            if !used_paths.insert(path.clone()) {
                return Err(ContentError::new(path, "duplicate catalog path"));
            }
            let source: CampaignFile = parse(bundle, path)?;
            identifier(&source.id, path)?;
            reference(&source.leader, &types, path)?;
            if source.name.is_empty()
                || source.tagline.is_empty()
                || source.description.is_empty()
                || source.stages.is_empty()
            {
                return Err(ContentError::new(
                    path,
                    "campaign name and stages are required",
                ));
            }
            validate_characters(&source.characters, path)?;
            validate_speech(&source.ending, &source.characters, path)?;
            let mut missions = Vec::new();
            let mut stage_ids = HashSet::new();
            for stage_path in source.stages {
                let stage_path = documents::stage_path(path, &stage_path)?;
                if !used_paths.insert(stage_path.clone()) {
                    return Err(ContentError::new(&stage_path, "duplicate catalog path"));
                }
                let mut stage = documents::stage(bundle, &stage_path, &items)?;
                let state = stage.state.resolve(&units, &types, &stage_path)?;
                identifier(&stage.id, &stage_path)?;
                if !stage_ids.insert(stage.id.clone())
                    || stage.id != state.map_id
                    || stage.id != stage.mission.map.id
                {
                    return Err(ContentError::new(
                        &stage_path,
                        "duplicate or mismatched stage/map identifier",
                    ));
                }
                validate_character_references(
                    &mut stage.mission,
                    &state,
                    &source.characters,
                    &stage_path,
                )?;
                validate_mission(
                    &stage.mission,
                    &state,
                    &types,
                    &units,
                    &terrains,
                    &stage_path,
                )?;
                map_definitions.push(documents::map_metadata(
                    bundle,
                    &stage_path,
                    &state,
                    Some(stage.mission.map.units.clone()),
                    source.human,
                )?);
                insert_map(&mut maps, state, &terrains, &types, &stage_path)?;
                missions.push(stage.mission);
            }
            let id = source.id.clone();
            if campaigns
                .insert(
                    id,
                    Campaign {
                        id: source.id,
                        name: source.name,
                        characters: source.characters,
                        tagline: source.tagline,
                        description: source.description,
                        short_description: source.short_description,
                        race: source.race,
                        leader: source.leader,
                        missions,
                        ending: source.ending,
                        human: source.human,
                    },
                )
                .is_some()
            {
                return Err(ContentError::new(path, "duplicate campaign identifier"));
            }
        }
        let recruitment: RecruitmentProfiles = if let Some(path) = &manifest.recruitment {
            let profiles: RecruitmentProfiles = parse(bundle, path)?;
            profiles
                .validate()
                .map_err(|message| ContentError::new(path, message))?;
            profiles
        } else {
            RecruitmentProfiles::default()
        };
        let rosters: Vec<ArmyRoster> = parse(bundle, &manifest.simulation.rosters)?;
        let arena: ArenaDefaults = parse(bundle, &manifest.simulation.arena)?;
        let campaign_defaults: CampaignDefaults = parse(bundle, &manifest.simulation.campaign)?;
        let training: TrainingDefaults = parse(bundle, &manifest.simulation.rl)?;
        validate_simulation(
            &rosters,
            &arena,
            &campaign_defaults,
            &types,
            &maps,
            &training,
            &terrain,
        )?;
        unique(
            campaign_defaults
                .default_campaigns
                .iter()
                .map(String::as_str),
            "simulation/campaign.json",
        )?;
        for id in campaign_defaults
            .campaigns
            .keys()
            .chain(&campaign_defaults.default_campaigns)
        {
            if !campaigns.contains_key(id) {
                return Err(ContentError::new(
                    "simulation/campaign.json",
                    format!("unknown campaign {id}"),
                ));
            }
        }
        // Different authored units often have identical movement rules. Their
        // distance fields and ordered discovery can share one cache identity.
        let route_classes = (0..units.len())
            .map(|kind| {
                (0..=kind)
                    .find(|&other| units[other].costs == units[kind].costs)
                    .unwrap()
            })
            .collect();
        let movement_classes = (0..units.len())
            .map(|kind| {
                (0..=kind)
                    .find(|&other| {
                        units[other].costs == units[kind].costs
                            && units[other].r#move == units[kind].r#move
                    })
                    .unwrap()
            })
            .collect();
        for state in maps.values() {
            let characters = scenario_characters
                .get(&(state.map_id.clone(), state.map_revision))
                .map(Vec::as_slice)
                .unwrap_or_else(|| {
                    campaigns
                        .values()
                        .find(|c| c.missions.iter().any(|m| m.map.id == state.map_id))
                        .map_or(&[][..], |c| c.characters.as_slice())
                });
            for unit in &state.units {
                if let Some(id) = &unit.character {
                    character_ref(id, characters, &state.map_id)?;
                }
            }
            for faction in &state.factions {
                if let Some(transfer) = &faction.transfer {
                    transfer
                        .when
                        .condition
                        .validate_characters(characters)
                        .map_err(|e| ContentError::new(&state.map_id, e))?;
                }
            }
        }
        for map in &map_definitions {
            let state = maps
                .get(&(map.id.clone(), map.revision))
                .expect("authored map");
            let characters = scenario_characters
                .get(&(map.id.clone(), map.revision))
                .map(Vec::as_slice)
                .unwrap_or_else(|| {
                    campaigns
                        .values()
                        .find(|c| c.missions.iter().any(|m| m.map.id == map.id))
                        .map_or(&[][..], |c| c.characters.as_slice())
                });
            for rule in map
                .terrain
                .iter()
                .filter_map(|_tile| None::<&ConditionRule>)
                .chain(
                    map.terrain
                        .iter()
                        .filter_map(|tile| tile.light.as_ref())
                        .filter_map(|light| light.when.as_ref()),
                )
            {
                rule.condition
                    .validate_characters(characters)
                    .map_err(|e| ContentError::new(&map.id, e))?;
                rule.validate_references(&types, &state.factions)
                    .map_err(|message| ContentError::new(&map.id, message))?;
            }
        }
        Ok(Self {
            content_fingerprint: fingerprint,
            abilities,
            recruitment,
            concealment_visuals,
            items,
            terrain_types: terrain.iter().map(|t| t.id).collect(),
            terrain_roles: terrain.iter().map(|t| t.role).collect(),
            terrain_names,
            terrain_labels: terrain.iter().map(|t| t.name.clone()).collect(),
            terrain_definitions: terrain,
            race_definitions: races.into_iter().map(|(_, race)| race).collect(),
            map_definitions,
            units: units.into(),
            movement_classes,
            route_classes,
            types,
            terrains,
            maps,
            #[cfg(not(target_arch = "wasm32"))]
            training,
            campaigns: campaigns
                .into_iter()
                .map(|(id, campaign)| (id, CampaignRules::from(campaign)))
                .collect(),
            rosters,
            #[cfg(not(target_arch = "wasm32"))]
            arena,
            #[cfg(not(target_arch = "wasm32"))]
            campaign_defaults,
        })
    }
}

/// SHA-256 of the exact supplied documents, in lexicographic path order.
/// Formatting changes deliberately change the fingerprint alongside rule edits.
pub fn content_fingerprint(bundle: &JsonBundle) -> String {
    let mut digest = Sha256::new();
    for (path, source) in bundle {
        digest.update(path.as_bytes());
        digest.update([0]);
        digest.update(source.as_bytes());
    }
    format!("{:x}", digest.finalize())
}

fn insert_map(
    maps: &mut HashMap<(String, u32), State>,
    state: State,
    terrains: &HashMap<String, usize>,
    types: &HashMap<String, usize>,
    path: &str,
) -> Result<(), ContentError> {
    identifier(&state.map_id, path)?;
    if state.map_revision == 0 || state.cols <= 0 || state.rows <= 0 || state.tiles.is_empty() {
        return Err(ContentError::new(
            path,
            "map revision, dimensions and tiles must be positive",
        ));
    }
    unique(state.tiles.iter().map(|t| t.id.as_str()), path)?;
    unique(
        state.tiles.iter().filter_map(|t| t.location.as_deref()),
        path,
    )?;
    unique(state.units.iter().map(|u| u.id.as_str()), path)?;
    unique(state.units.iter().map(|u| u.tile), path)?;
    let mut coordinates = HashSet::new();
    for tile in &state.tiles {
        if !tile.valid_connections() {
            return Err(ContentError::new(
                path,
                format!("invalid artwork connections {}", tile.id),
            ));
        }
        if !terrains.contains_key(&tile.terrain) {
            return Err(ContentError::new(
                path,
                format!("unknown terrain {}", tile.terrain),
            ));
        }
        if tile.id != format!("{},{}", tile.col, tile.row) {
            return Err(ContentError::new(
                path,
                "tile address must match its coordinates",
            ));
        }
        if let Some(location) = &tile.location {
            identifier(location, path)?;
        }
        if tile.col < 0
            || tile.col >= state.cols
            || tile.row < 0
            || tile.row >= state.rows
            || !coordinates.insert((tile.col, tile.row))
        {
            return Err(ContentError::new(
                path,
                format!("invalid tile coordinates {}", tile.id),
            ));
        }
    }
    for unit in &state.units {
        reference(&unit.r#type, types, path)?;
        if !state.tiles.iter().any(|t| t.hex() == unit.tile) || unit.hp <= 0 {
            return Err(ContentError::new(
                path,
                format!("invalid unit placement {}", unit.id),
            ));
        }
    }
    let key = (state.map_id.clone(), state.map_revision);
    if maps.insert(key, state).is_some() {
        return Err(ContentError::new(
            path,
            "duplicate map identifier and revision",
        ));
    }
    Ok(())
}
fn validate_characters(characters: &[Character], path: &str) -> Result<(), ContentError> {
    unique(characters.iter().map(|c| c.id.as_str()), path)?;
    for character in characters {
        identifier(&character.id, path)?;
        if character.name.trim().is_empty() {
            return Err(ContentError::new(
                path,
                "character display name must not be empty",
            ));
        }
    }
    Ok(())
}
fn character_ref(id: &str, characters: &[Character], path: &str) -> Result<(), ContentError> {
    if characters.iter().any(|c| c.id == id) {
        Ok(())
    } else {
        Err(ContentError::new(path, format!("unknown character {id}")))
    }
}
fn resolve_dialogues(
    lines: &mut [Dialogue],
    characters: &[Character],
    path: &str,
) -> Result<(), ContentError> {
    for line in lines {
        if let Some(id) = &line.character {
            character_ref(id, characters, path)?;
            line.speaker.clear();
        } else if line.speaker.trim().is_empty() {
            return Err(ContentError::new(
                path,
                "dialogue requires a character ID or a narrator label",
            ));
        } else if characters.iter().any(|c| c.name == line.speaker) {
            return Err(ContentError::new(
                path,
                "named dialogue speakers must reference a character ID",
            ));
        }
    }
    Ok(())
}
fn validate_speech(
    lines: &[Speech],
    characters: &[Character],
    path: &str,
) -> Result<(), ContentError> {
    ScriptEvent {
        observer: None,
        id: "speech-validation".into(),
        when: When::ChapterStarted(true),
        remembers: true,
        priority: 0,
        objective: None,
        actions: vec![EventAction::Say(lines.to_vec())],
    }
    .validate_characters(characters, path)
}
fn validate_character_references(
    mission: &mut Mission,
    state: &State,
    characters: &[Character],
    path: &str,
) -> Result<(), ContentError> {
    let check = |id: &str| character_ref(id, characters, path);
    let condition = |c: &Condition| {
        c.validate_characters(characters)
            .map_err(|e| ContentError::new(path, e))
    };
    let placements = |units: &[StartingUnit]| -> Result<(), ContentError> {
        for unit in units {
            if let Some(id) = &unit.character {
                check(id)?;
            }
        }
        Ok(())
    };
    placements(&mission.map.units)?;
    for w in mission.story_conditions() {
        let e = ScriptEvent {
            observer: Some("player".into()),
            id: "story-condition".into(),
            when: w.clone(),
            remembers: true,
            priority: 0,
            objective: None,
            actions: vec![],
        };
        e.validate_characters(characters, path)?;
    }
    for event in &mission.scripted_events {
        event.validate_characters(characters, path)?;
    }
    for id in &mission.required_companions {
        check(id)?;
    }
    for arrival in &mission.arrivals {
        check(&arrival.character)?;
    }
    for goal in mission.all_goals() {
        if let Some(id) = goal.companion() {
            check(id)?;
        }
        if let Some(c) = goal.visible_when() {
            condition(c)?;
        }
    }
    for loss in &mission.lose_conditions {
        condition(&loss.condition)?;
    }
    for group in &mission.enemy_groups {
        if let Some(rule) = &group.when {
            condition(&rule.condition)?;
        }
        if let Some(GroupOrder::Hold { when: Some(c), .. }) = &group.order {
            condition(c)?;
        }
    }
    for tile in &state.tiles {
        if let Some(rule) = tile.light.as_ref().and_then(|l| l.when.as_ref()) {
            condition(&rule.condition)?;
        }
    }
    for faction in &state.factions {
        if let Some(rule) = &faction.transfer {
            condition(&rule.when.condition)?;
        }
    }
    validate_speech(&mission.intro, characters, path)?;
    validate_speech(&mission.victory, characters, path)?;
    for event in &mut mission.events {
        if let Trigger::Condition { condition: c, .. } = &event.trigger {
            condition(c)?;
        }
        if let Some(effect) = &event.evacuate {
            if let Some(id) = &effect.units.character {
                check(id)?;
            }
        }
        for reward in &event.items {
            if let Some(id) = &reward.recipient.character {
                check(id)?;
            }
        }
        if let Some(spawn) = &event.spawn {
            for unit in &spawn.units {
                if let Some(id) = &unit.character {
                    check(id)?;
                }
            }
        }
        resolve_dialogues(&mut event.dialogue, characters, path)?;
        if let Some(lines) = &mut event.war_dialogue {
            resolve_dialogues(lines, characters, path)?;
        }
    }
    for wave in &mut mission.waves {
        placements(&wave.units)?;
        resolve_dialogues(&mut wave.dialogue, characters, path)?;
    }
    if let Some(refuge) = &mut mission.refuge {
        resolve_dialogues(&mut refuge.escalation, characters, path)?;
        resolve_dialogues(&mut refuge.war_victory, characters, path)?;
    }
    let patch = |p: &mut MissionPatch| -> Result<(), ContentError> {
        if let Some(units) = &p.reinforcements {
            placements(units)?;
        }
        if let Some(lines) = &mut p.intro {
            resolve_dialogues(lines, characters, path)?;
        }
        if let Some(lines) = &mut p.victory {
            resolve_dialogues(lines, characters, path)?;
        }
        Ok(())
    };
    if let Some(p) = &mut mission.without_dain {
        patch(p)?;
    }
    if let Some(patches) = &mut mission.companion_losses {
        for (id, p) in patches {
            check(id)?;
            patch(p)?;
        }
    }
    Ok(())
}

fn validate_mission(
    mission: &Mission,
    state: &State,
    types: &HashMap<String, usize>,
    units: &[UnitRule],
    terrains: &HashMap<String, usize>,
    path: &str,
) -> Result<(), ContentError> {
    let tile_ref = |id: &TileRef| -> Result<(), ContentError> {
        if !state.tiles.iter().any(|t| t.matches_reference(id)) {
            return Err(ContentError::new(path, format!("unknown tile {id}")));
        }
        Ok(())
    };
    unique(
        mission
            .scripted_events
            .iter()
            .filter(|e| e.objective.is_some())
            .map(ScriptEvent::objective_id),
        path,
    )?;
    let ids: HashSet<_> = mission
        .scripted_events
        .iter()
        .filter(|e| e.objective.is_some())
        .map(ScriptEvent::objective_id)
        .collect();
    // Objective predicates are shared by victory and queries; reject unknown and
    // cyclic references at load time, even in a short-circuited boolean branch.
    let mut conditions = mission.story_conditions();
    for event in &mission.scripted_events {
        conditions.push(&event.when);
        if let Some(objective) = &event.objective {
            conditions.extend(objective.visible_when.iter());
            conditions.extend(objective.available_when.iter());
            conditions.extend(objective.satisfied_when.iter());
        }
    }
    for condition in conditions {
        let mut unknown = None;
        condition.visit_objective_refs(&mut |id| {
            if !ids.contains(id) {
                unknown = Some(id.to_owned());
            }
        });
        if let Some(id) = unknown {
            return Err(ContentError::new(path, format!("unknown objective {id}")));
        }
    }
    let objectives: HashMap<_, _> = mission
        .scripted_events
        .iter()
        .filter_map(|e| e.objective.as_ref().map(|o| (e.objective_id(), o)))
        .collect();
    fn check_dependencies<'a>(
        id: &'a str,
        objectives: &HashMap<&'a str, &'a EventObjective>,
        visiting: &mut HashSet<String>,
        checked: &mut HashSet<String>,
        path: &str,
    ) -> Result<(), ContentError> {
        if checked.contains(id) {
            return Ok(());
        }
        if !visiting.insert(id.into()) {
            return Err(ContentError::new(
                path,
                format!("cyclic objective satisfaction: {id}"),
            ));
        }
        if let Some(condition) = &objectives[id].satisfied_when {
            let mut dependencies = vec![];
            condition.visit_objective_refs(&mut |other| dependencies.push(other.to_owned()));
            for other in dependencies {
                let (id, _) = objectives
                    .get_key_value(other.as_str())
                    .expect("validated objective reference");
                check_dependencies(id, objectives, visiting, checked, path)?;
            }
        }
        visiting.remove(id);
        checked.insert(id.into());
        Ok(())
    }
    let mut visiting = HashSet::new();
    let mut checked = HashSet::new();
    for id in objectives.keys() {
        check_dependencies(id, &objectives, &mut visiting, &mut checked, path)?;
    }
    for action in mission
        .scripted_events
        .iter()
        .flat_map(ScriptEvent::actions_recursive)
    {
        if let EventAction::FailObjective(id) | EventAction::CompleteObjective(id) = action {
            if !ids.contains(id.as_str()) {
                return Err(ContentError::new(path, format!("unknown objective {id}")));
            }
        }
    }
    for condition in mission.story_conditions() {
        if !condition.state_only() {
            return Err(ContentError::new(
                path,
                "story text conditions must be state predicates",
            ));
        }
        let check = ScriptEvent {
            observer: Some("player".into()),
            id: "story-condition".into(),
            when: condition.clone(),
            remembers: true,
            priority: 0,
            objective: None,
            actions: vec![],
        };
        check.validate(
            &state.tiles,
            &state.factions,
            &state.vision_groups,
            &std::collections::HashMap::new(),
            path,
        )?;
        for selector in check.selectors() {
            for id in selector.unit_type.iter().chain(&selector.unit_types) {
                reference(id, types, path)?;
            }
        }
    }
    for event in &mission.scripted_events {
        for selector in event.selectors() {
            for id in selector.unit_type.iter().chain(&selector.unit_types) {
                reference(id, types, path)?;
            }
            if let Some(id) = &selector.faction {
                if !state.factions.iter().any(|f| &f.id == id) {
                    return Err(ContentError::new(
                        path,
                        format!("unknown selector faction {id}"),
                    ));
                }
            }
        }
        for action in event.actions_recursive() {
            match action {
                EventAction::Spawn(spec) => {
                    if let Some(group) = &spec.ai_group {
                        if !mission.enemy_groups.iter().any(|g| &g.id == group) {
                            return Err(ContentError::new(
                                path,
                                format!("unknown spawn AI group {group}"),
                            ));
                        }
                    }
                    for member in &spec.units {
                        reference(&member.member().unit_type, types, path)?;
                    }
                }
                EventAction::CreateMark(spec) => {
                    if let Some(light) = &spec.light {
                        light
                            .validate(&state.tiles, &mission.events)
                            .map_err(|e| ContentError::new(path, e))?;
                        if let Some(rule) = &light.when {
                            rule.validate_references(types, &state.factions)
                                .map_err(|e| ContentError::new(path, e))?;
                        }
                    }
                }
                EventAction::SetTerrain(spec) => {
                    reference(&spec.terrain, terrains, path)?;
                    let mut tile = state.tiles[0].clone();
                    tile.terrain = spec.terrain.clone();
                    tile.connections = None;
                    tile.walls = None;
                    tile.dead_ends = None;
                    if !tile.valid_connections() {
                        return Err(ContentError::new(
                            path,
                            "setTerrain requires complete authored geometry for connected terrain",
                        ));
                    }
                }
                EventAction::UnlockRecruits(spec) | EventAction::Recruits(spec) => {
                    for unit in &spec.units {
                        reference(&unit.unit, types, path)?;
                    }
                }
                _ => {}
            }
        }
    }
    for loss in &mission.lose_conditions {
        loss.condition
            .validate_observer(loss.observer.as_deref(), &state.factions)
            .map_err(|e| ContentError::new(path, e))?;
        if loss.label.trim().is_empty() || loss.message.trim().is_empty() {
            return Err(ContentError::new(path, "empty defeat condition text"));
        }
        loss.condition
            .validate(&state.tiles, &mission.events, false)
            .map_err(|message| ContentError::new(path, message))?;
        loss.condition
            .validate_references(types, &state.factions)
            .map_err(|message| ContentError::new(path, message))?;
    }
    validate_faction_conditions(&state.factions, &state.tiles, &mission.events, types)
        .map_err(|message| ContentError::new(path, message))?;
    unique(mission.events.iter().map(|e| e.id.as_str()), path)?;
    unique(mission.waves.iter().map(|w| w.id.as_str()), path)?;
    let events: HashSet<&str> = mission.events.iter().map(|e| e.id.as_str()).collect();
    let event_ref = |id: &str| -> Result<(), ContentError> {
        if !events.contains(id) {
            return Err(ContentError::new(path, format!("unknown event {id}")));
        }
        Ok(())
    };
    unique(
        mission.enemy_groups.iter().map(|group| group.id.as_str()),
        path,
    )?;
    for group in &mission.enemy_groups {
        identifier(&group.id, path)?;
        if let Some(order) = &group.order {
            match order {
                GroupOrder::Hold {
                    area,
                    when,
                    observer,
                    ..
                } => {
                    if let Some(condition) = when {
                        condition
                            .validate_observer(observer.as_deref(), &state.factions)
                            .map_err(|e| ContentError::new(path, e))?;
                    } else if let Some(id) = observer {
                        validate_faction_reference(&state.factions, id)
                            .map_err(|e| ContentError::new(path, e))?;
                    }
                    if let Some(condition) = when {
                        condition
                            .validate(&state.tiles, &mission.events, false)
                            .map_err(|message| ContentError::new(path, message))?;
                        condition
                            .validate_references(types, &state.factions)
                            .map_err(|message| ContentError::new(path, message))?;
                    }
                    if area.is_empty() {
                        return Err(ContentError::new(path, "hold area must not be empty"));
                    }
                    unique(area.iter(), path)?;
                    for tile in area {
                        tile_ref(tile)?;
                    }
                }
            }
        }
        if let Some(rule) = &group.when {
            rule.condition
                .validate(&state.tiles, &mission.events, false)
                .map_err(|message| ContentError::new(path, message))?;
            rule.validate_references(types, &state.factions)
                .map_err(|message| ContentError::new(path, message))?;
        }
    }
    let group_ref = |id: &str| -> Result<(), ContentError> {
        if !mission.enemy_groups.iter().any(|group| group.id == id) {
            return Err(ContentError::new(
                path,
                format!("unknown enemy group: {id}"),
            ));
        }
        Ok(())
    };
    for unit in &state.units {
        if let Some(id) = &unit.ai_group {
            group_ref(id)?;
        }
    }
    let starting = |placements: &[StartingUnit]| -> Result<(), ContentError> {
        for unit in placements {
            validate_faction_reference(&state.factions, &unit.faction)
                .map_err(|message| ContentError::new(path, message))?;
            if let Some(id) = &unit.ai_group {
                group_ref(id)?;
            }
            reference(&unit.r#type, types, path)?;
            validate_equipment(&unit.items, &units[types[&unit.r#type]].attacks, path)?;
            tile_ref(&TileRef::Hex(unit.tile))?;
        }
        Ok(())
    };
    starting(&mission.map.units)?;
    let validate_recruitment =
        |pools: &BTreeMap<String, Vec<FactionRecruit>>| -> Result<(), ContentError> {
            for (id, recruits) in pools {
                if !state.factions.iter().any(|f| &f.id == id) {
                    return Err(ContentError::new(
                        path,
                        format!("unknown recruitment faction {id}"),
                    ));
                }
                unique(recruits.iter().map(|r| r.unit.as_str()), path)?;
                for recruit in recruits {
                    reference(&recruit.unit, types, path)?;
                    if recruit.cost.is_some_and(|cost| cost < 0) {
                        return Err(ContentError::new(path, "negative recruitment price"));
                    }
                }
            }
            Ok(())
        };
    validate_recruitment(&mission.recruitment)?;
    if let Some(id) = &mission.enemy_leader_post {
        tile_ref(id)?;
    }
    if mission.briefing.is_empty()
        || (mission.goals.is_empty() && mission.scripted_events.is_empty())
    {
        return Err(ContentError::new(
            path,
            "mission briefing and goals are required",
        ));
    }
    for goal in mission.all_goals() {
        if let Some(condition) = goal.visible_when() {
            condition
                .validate(&state.tiles, &mission.events, false)
                .map_err(|e| ContentError::new(path, e))?;
            condition
                .validate_references(types, &state.factions)
                .map_err(|e| ContentError::new(path, e))?;
        }
        for site in goal.sites() {
            tile_ref(&site)?;
        }
        if let Some(id) = goal.unit_type() {
            reference(id, types, path)?;
        }
        if let Some(id) = goal.event() {
            event_ref(id)?;
        }
        if let Some(id) = goal.start_event() {
            event_ref(id)?;
        }
        if let Some(name) = goal.companion() {
            if !mission
                .map
                .units
                .iter()
                .any(|unit| unit.faction == "player" && unit.character.as_ref() == Some(name))
            {
                return Err(ContentError::new(
                    path,
                    format!("unknown goal companion {name}"),
                ));
            }
        }
        if goal.turns() == Some(0) {
            return Err(ContentError::new(path, "goal turns must be positive"));
        }
    }
    for event in &mission.events {
        validate_recruitment(&event.recruitment)?;
        if let Some(effect) = &event.evacuate {
            tile_ref(&effect.tile)?;
            if effect
                .units
                .character
                .as_ref()
                .is_some_and(|name| name.is_empty())
            {
                return Err(ContentError::new(path, "empty evacuation unit name"));
            }
        }
        for reward in &event.items {
            reward.item.validate(path)?;
            if reward.item.attacks.iter().any(|a| {
                units
                    .iter()
                    .any(|unit| unit.attacks.iter().any(|base| base.id == a.id))
            }) {
                return Err(ContentError::new(
                    path,
                    "equipment attacks need distinct IDs from unit attacks",
                ));
            }
            if reward
                .recipient
                .character
                .as_ref()
                .is_some_and(|name| name.is_empty())
            {
                return Err(ContentError::new(path, "empty item recipient name"));
            }
        }
        identifier(&event.id, path)?;
        if let Some(choice) = &event.choice {
            identifier(choice, path)?;
        }
        if let Some(group) = &event.spawn {
            for unit in &group.units {
                validate_faction_reference(
                    &state.factions,
                    unit.faction
                        .as_deref()
                        .or(group.faction.as_deref())
                        .ok_or_else(|| {
                            ContentError::new(path, "spawn requires an explicit faction")
                        })?,
                )
                .map_err(|message| ContentError::new(path, message))?;
            }
            if let Some(id) = &group.ai_group {
                group_ref(id)?;
            }
            if group.area.is_empty() || group.units.is_empty() {
                return Err(ContentError::new(
                    path,
                    "spawn area and units must not be empty",
                ));
            }
            unique(group.area.iter(), path)?;
            unique(group.units.iter().map(|unit| unit.id.as_str()), path)?;
            for tile in &group.area {
                tile_ref(tile)?;
            }
            for unit in &group.units {
                identifier(&unit.id, path)?;
                reference(&unit.r#type, types, path)?;
            }
        }
        if let Trigger::Condition {
            condition,
            observer,
        } = &event.trigger
        {
            condition
                .validate_observer(observer.as_deref(), &state.factions)
                .map_err(|e| ContentError::new(path, e))?;
            condition
                .validate_references(types, &state.factions)
                .map_err(|message| ContentError::new(path, message))?;
        }
        match &event.trigger {
            Trigger::Condition { condition, .. } => condition
                .validate(&state.tiles, &mission.events, false)
                .map_err(|message| ContentError::new(path, message))?,
            Trigger::Visit { tile }
            | Trigger::Held { tile, .. }
            | Trigger::Control { tile, .. } => tile_ref(tile)?,
            Trigger::Round { round } => {
                if *round == 0 {
                    return Err(ContentError::new(path, "event round must be positive"));
                }
            }
        }
        for id in event.requires_event.iter().chain(&event.unless_event) {
            event_ref(id)?;
        }
    }
    unique(
        mission
            .arrivals
            .iter()
            .map(|arrival| arrival.character.as_str()),
        path,
    )?;
    for arrival in &mission.arrivals {
        if arrival.character.is_empty() {
            return Err(ContentError::new(path, "empty automatic companion name"));
        }
        tile_ref(&TileRef::Hex(arrival.tile))?;
    }
    for goal in mission.all_goals() {
        if let Goal::Hold { unit_types, .. } = goal {
            for kind in unit_types {
                reference(kind, types, path)?;
            }
        }
    }
    for event in &mission.events {
        for item in &event.ground_items {
            tile_ref(&TileRef::Hex(item.tile))?;
            item.item.validate(path)?;
        }
        if let Trigger::Held { turns, .. } = event.trigger {
            if turns == 0 {
                return Err(ContentError::new(path, "held trigger needs positive turns"));
            }
        }
    }
    for wave in &mission.waves {
        identifier(&wave.id, path)?;
        starting(&wave.units)?;
        if let Some(id) = &wave.requires_unsealed {
            tile_ref(id)?;
        }
    }
    if let Some(refuge) = &mission.refuge {
        event_ref(&refuge.medicine_event)?;
    }
    let validate_patch = |patch: &MissionPatch| -> Result<(), ContentError> {
        if let Some(recruitment) = &patch.recruitment {
            validate_recruitment(recruitment)?;
        }
        if let Some(units) = &patch.reinforcements {
            starting(units)?;
        }
        Ok(())
    };
    if let Some(patches) = &mission.companion_losses {
        for patch in patches.values() {
            validate_patch(patch)?;
        }
    }
    if let Some(patch) = &mission.without_dain {
        validate_patch(patch)?;
    }
    Ok(())
}
fn validate_simulation(
    rosters: &[ArmyRoster],
    arena: &ArenaDefaults,
    campaign: &CampaignDefaults,
    types: &HashMap<String, usize>,
    maps: &HashMap<(String, u32), State>,
    training: &TrainingDefaults,
    terrain: &[TerrainDefinition],
) -> Result<(), ContentError> {
    let path = "simulation/rosters.json";
    unique(rosters.iter().map(|r| r.id.as_str()), path)?;
    if rosters.is_empty() {
        return Err(ContentError::new(path, "rosters must be nonempty"));
    }
    for roster in rosters {
        identifier(&roster.id, path)?;
        reference(&roster.leader, types, path)?;
        unique(roster.pool.iter().map(String::as_str), path)?;
        for id in &roster.pool {
            reference(id, types, path)?;
        }
    }
    let path = "simulation/arena.json";
    unique(arena.scenarios.iter().map(|s| s.id.as_str()), path)?;
    unique(arena.default_scenarios.iter().map(String::as_str), path)?;
    if arena.scenarios.is_empty()
        || arena.default_scenarios.is_empty()
        || arena.default_max_rounds == 0
        || campaign.default_max_rounds == 0
    {
        return Err(ContentError::new(
            path,
            "arena scenarios, default scenarios and round limits must be nonempty/positive",
        ));
    }
    for id in &arena.default_scenarios {
        if !arena.scenarios.iter().any(|s| &s.id == id) {
            return Err(ContentError::new(
                path,
                format!("unknown default arena {id}"),
            ));
        }
    }
    for scenario in &arena.scenarios {
        identifier(&scenario.id, path)?;
        unique(scenario.territory.iter(), path)?;
        if scenario.variants.is_empty() || scenario.territory.is_empty() || scenario.hold_turns == 0
        {
            return Err(ContentError::new(
                path,
                "arena variants, territory and holdTurns must be nonempty/positive",
            ));
        }
        for variant in &scenario.variants {
            let map = maps
                .iter()
                .filter(|((id, _), _)| id == &variant.map)
                .max_by_key(|((_, revision), _)| revision)
                .map(|(_, map)| map)
                .ok_or_else(|| {
                    ContentError::new(path, format!("unknown arena map {}", variant.map))
                })?;
            if scenario
                .territory
                .iter()
                .any(|hex| !map.tiles.iter().any(|t| t.hex() == *hex))
            {
                return Err(ContentError::new(
                    path,
                    "arena territory is outside its map",
                ));
            }
            match variant.forces {
                ArenaForces::Scenario => {
                    for side in [TurnPhase::Player, TurnPhase::Ai] {
                        if !map.units.iter().any(|u| {
                            map.factions
                                .iter()
                                .any(|f| f.id == u.faction && f.phase == side)
                                && u.role == Some(Role::Leader)
                        }) {
                            return Err(ContentError::new(
                                path,
                                "scenario forces require leaders in both phases",
                            ));
                        }
                    }
                }
                ArenaForces::Selected { budget } => {
                    if budget <= 0 {
                        return Err(ContentError::new(
                            path,
                            "selected forces require a positive budget",
                        ));
                    }
                    for faction in ["player", "enemy"] {
                        if map
                            .tiles
                            .iter()
                            .filter(|tile| {
                                terrain.iter().any(|t| {
                                    t.id.as_str() == tile.terrain && t.role == TerrainRole::Keep
                                }) && tile.owner.as_deref() == Some(faction)
                            })
                            .count()
                            != 1
                        {
                            return Err(ContentError::new(
                                path,
                                "selected forces require one owned keep per side",
                            ));
                        }
                    }
                }
            }
        }
    }
    let path = "simulation/campaign.json";
    for (id, config) in &campaign.campaigns {
        identifier(id, path)?;
        unique(config.diplomacy.iter().map(String::as_str), path)?;
        if config.diplomacy.is_empty()
            || config
                .diplomacy
                .iter()
                .any(|m| !campaign.diplomacy.contains(m))
        {
            return Err(ContentError::new(
                path,
                "unknown or missing campaign diplomacy",
            ));
        }
        for route in config.routes.keys() {
            identifier(route, path)?;
        }
    }
    let path = "simulation/rl.json";
    unique(training.arenas.iter().map(|a| a.id.as_str()), path)?;
    if training.objectives.is_empty()
        || training.arenas.is_empty()
        || training.campaigns.is_empty()
        || training.opponents.is_empty()
        || training.recruiters.is_empty()
    {
        return Err(ContentError::new(
            path,
            "RL workload dimensions must be nonempty",
        ));
    }
    unique(training.objectives.iter().map(String::as_str), path)?;
    if training
        .objectives
        .iter()
        .any(|o| !["deathmatch", "territory"].contains(&o.as_str()))
    {
        return Err(ContentError::new(path, "unknown RL arena objective"));
    }
    for a in &training.arenas {
        if !arena.scenarios.iter().any(|s| s.id == a.id) || a.pairs.is_empty() {
            return Err(ContentError::new(
                path,
                format!("unknown or empty RL arena {}", a.id),
            ));
        }
        unique(
            a.pairs.iter().map(|p| format!("{}/{}", p.player, p.enemy)),
            path,
        )?;
        for p in &a.pairs {
            for id in [&p.player, &p.enemy] {
                if !rosters.iter().any(|r| &r.id == id) {
                    return Err(ContentError::new(path, format!("unknown RL roster {id}")));
                }
            }
        }
    }
    for (id, variants) in &training.campaigns {
        let config = campaign
            .campaigns
            .get(id)
            .ok_or_else(|| ContentError::new(path, format!("unknown RL campaign {id}")))?;
        if variants.is_empty() {
            return Err(ContentError::new(
                path,
                "RL campaign variants must be nonempty",
            ));
        }
        unique(
            variants
                .iter()
                .map(|v| format!("{}/{}", v.objective, v.diplomacy)),
            path,
        )?;
        for v in variants {
            if !config.diplomacy.contains(&v.diplomacy)
                || v.objective != "authored" && !config.routes.contains_key(&v.objective)
            {
                return Err(ContentError::new(
                    path,
                    format!("unknown RL route/diplomacy for {id}"),
                ));
            }
        }
    }
    for (ids, allowed) in [
        (
            &training.opponents,
            [
                "classic",
                "rush",
                "balanced",
                "rotated",
                "situational",
                "predictor",
            ]
            .as_slice(),
        ),
        (
            &training.recruiters,
            ["balanced", "rotated", "situational", "predictor"].as_slice(),
        ),
    ] {
        unique(ids.iter().map(String::as_str), path)?;
        if ids.iter().any(|id| !allowed.contains(&id.as_str())) {
            return Err(ContentError::new(path, "unknown RL opponent or recruiter"));
        }
    }
    for (ids, allowed, path) in [
        (
            &arena.policies,
            ["classic", "rush", "balanced", "rotated", "situational"].as_slice(),
            "simulation/arena.json",
        ),
        (
            &campaign.policies,
            ["classic", "rush", "balanced", "rotated", "situational"].as_slice(),
            "simulation/campaign.json",
        ),
        (
            &campaign.diplomacy,
            ["unrestricted", "diplomatic"].as_slice(),
            "simulation/campaign.json",
        ),
    ] {
        unique(ids.iter().map(String::as_str), path)?;
        if ids.is_empty() || ids.iter().any(|id| !allowed.contains(&id.as_str())) {
            return Err(ContentError::new(
                path,
                "unknown or missing simulation strategy",
            ));
        }
    }
    Ok(())
}

/// The authored documents are also available without native filesystem APIs.
#[cfg(feature = "wasm")]
pub fn embedded_bundle() -> JsonBundle {
    documents::collect_bundle(|path| {
        EMBEDDED_DOCUMENTS
            .iter()
            .find(|(name, _)| *name == path)
            .map(|(_, source)| (*source).to_owned())
            .ok_or_else(|| ContentError::new(path, "missing embedded catalog document"))
    })
    .expect("compiled catalog document references")
}

#[cfg(test)]
mod tests {
    #[cfg(feature = "wasm")]
    use super::embedded_bundle;
    use super::*;
    #[cfg(not(feature = "wasm"))]
    fn embedded_bundle() -> JsonBundle {
        documents::collect_bundle(|path| {
            std::fs::read_to_string(
                Path::new(env!("CARGO_MANIFEST_DIR"))
                    .join("../data")
                    .join(path),
            )
            .map_err(|error| ContentError::new(path, error.to_string()))
        })
        .expect("authored test catalog")
    }
    #[test]
    fn invalid_references_and_duplicates_report_source_document() {
        let mut bundle = embedded_bundle();
        let units = bundle.get_mut("game/units/humans/warden.json").unwrap();
        *units = units.replacen("\"warden\"", "\"adept\"", 1);
        let error = Rules::from_json_bundle(&bundle).unwrap_err();
        assert_eq!(error.path, "game/units/humans/adept.json");
        assert!(error.message.contains("duplicate"));
        let mut bundle = embedded_bundle();
        let roster = bundle.get_mut("simulation/rosters.json").unwrap();
        *roster = roster.replacen("\"commander\"", "\"missing-unit\"", 1);
        let error = Rules::from_json_bundle(&bundle).unwrap_err();
        assert!(error.message.contains("unknown unit missing-unit"));
    }
    #[test]
    fn missing_required_stats_and_documents_are_errors() {
        let mut bundle = embedded_bundle();
        let units = bundle.get_mut("game/units/humans/warden.json").unwrap();
        let mut document: serde_json::Value = serde_json::from_str(units).unwrap();
        document.as_object_mut().unwrap().remove("hp");
        *units = serde_json::to_string(&document).unwrap();
        assert!(
            Rules::from_json_bundle(&bundle)
                .unwrap_err()
                .message
                .contains("missing field")
        );
        let mut bundle = embedded_bundle();
        bundle.remove("game/races/merfolk.json");
        assert_eq!(
            Rules::from_json_bundle(&bundle).unwrap_err().path,
            "game/races/merfolk.json"
        );
    }
    #[test]
    fn roles_are_required_and_race_errors_identify_the_individual_document() {
        let mut bundle = embedded_bundle();
        let unit = bundle.get_mut("game/units/humans/scout.json").unwrap();
        *unit = unit.replace("\"role\": \"flank\",", "");
        let error = Rules::from_json_bundle(&bundle).unwrap_err();
        assert_eq!(error.path, "game/units/humans/scout.json");
        assert!(error.message.contains("role"));
        let mut bundle = embedded_bundle();
        let race = bundle.get_mut("game/races/human.json").unwrap();
        *race = race.replace("\"id\": \"human\"", "\"id\": \"merfolk\"");
        let error = Rules::from_json_bundle(&bundle).unwrap_err();
        assert_eq!(error.path, "game/races/human.json");
        assert!(error.message.contains("duplicate race"));
    }
    #[test]
    fn manifest_rejects_traversal_and_unsupported_schema() {
        let mut bundle = embedded_bundle();
        let manifest = bundle.get_mut("manifest.json").unwrap();
        *manifest = manifest.replace("game/terrain.json", "../terrain.json");
        assert!(
            Rules::from_json_bundle(&bundle)
                .unwrap_err()
                .message
                .contains("traversal")
        );
        let mut bundle = embedded_bundle();
        let manifest = bundle.get_mut("manifest.json").unwrap();
        *manifest = manifest.replace("\"schemaVersion\": 3", "\"schemaVersion\": 99");
        assert!(
            Rules::from_json_bundle(&bundle)
                .unwrap_err()
                .message
                .contains("schemaVersion")
        );
    }
    #[test]
    fn metadata_and_exact_document_fingerprint_are_preserved() {
        let bundle = embedded_bundle();
        let rules = Rules::from_json_bundle(&bundle).unwrap();
        let adept = &rules.units[rules.types["adept"]];
        let authored: UnitSpecification = parse(&bundle, "game/units/humans/adept.json").unwrap();
        assert_eq!(adept.ability, authored.ability);
        assert_eq!(adept.description, authored.description);
        let campaign = &rules.campaigns["lantern-road"];
        assert!(!campaign.tagline.is_empty());
        assert!(!campaign.description.is_empty());
        assert_eq!(campaign.race, Race::Human);
        assert_eq!(rules.content_fingerprint, content_fingerprint(&bundle));
        assert_eq!(rules.content_fingerprint.len(), 64);
        let mut reformatted = bundle.clone();
        reformatted
            .get_mut("game/units/humans/warden.json")
            .unwrap()
            .push('\n');
        let changed = Rules::from_json_bundle(&reformatted).unwrap();
        assert_ne!(rules.content_fingerprint, changed.content_fingerprint);
        assert_eq!(adept.ability, changed.units[changed.types["adept"]].ability);
    }

    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn native_reload_reads_metadata_edits_without_rebuilding() {
        struct Directory(std::path::PathBuf);
        impl Drop for Directory {
            fn drop(&mut self) {
                let _ = std::fs::remove_dir_all(&self.0);
            }
        }
        let root = Directory(std::env::temp_dir().join(format!(
            "hex-command-catalog-{}-{}", std::process::id(),
            std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()
        )));
        for (path, source) in embedded_bundle() {
            let target = root.0.join(path);
            std::fs::create_dir_all(target.parent().unwrap()).unwrap();
            std::fs::write(target, source).unwrap();
        }
        let original = Rules::load_from(&root.0).unwrap();
        let path = root.0.join("game/units/humans/adept.json");
        let edited =
            std::fs::read_to_string(&path)
                .unwrap()
                .replacen("Stone spark", "Revised spark", 1);
        std::fs::write(path, edited).unwrap();
        let commander = root.0.join("game/units/humans/commander.json");
        let original_hp = original.units[original.types["commander"]].hp;
        let revised_hp = original_hp + 3;
        let mut edited: serde_json::Value =
            serde_json::from_str(&std::fs::read_to_string(&commander).unwrap()).unwrap();
        edited["hp"] = serde_json::json!(revised_hp);
        std::fs::write(commander, serde_json::to_vec(&edited).unwrap()).unwrap();
        let reloaded = Rules::load_from(&root.0).unwrap();
        assert_eq!(
            reloaded.units[reloaded.types["adept"]].ability,
            "Revised spark"
        );
        assert_eq!(
            original.units[original.types["adept"]].ability,
            "Stone spark"
        );
        assert_ne!(original.content_fingerprint, reloaded.content_fingerprint);
        assert_eq!(original.rosters[0].pool, reloaded.rosters[0].pool);
        let initial = reloaded.maps[&("mirror".to_owned(), 1)].clone();
        assert_eq!(initial.units[0].r#type, "commander");
        assert_eq!(initial.units[0].hp, revised_hp);
        assert_eq!(
            original.maps[&("mirror".to_owned(), 1)].units[0].hp,
            original_hp
        );
    }
    #[test]
    fn scenario_visibility_is_explicit_and_does_not_change_loadability() {
        let mut bundle = embedded_bundle();
        let path = "game/scenario/mirror-v1/scenario.json";
        let mut map: serde_json::Value = serde_json::from_str(&bundle[path]).unwrap();
        for human in [true, false] {
            map["human"] = serde_json::json!(human);
            bundle.insert(path.to_owned(), serde_json::to_string(&map).unwrap());
            let rules = Rules::from_json_bundle(&bundle).unwrap();
            let metadata = rules
                .map_definitions
                .iter()
                .find(|map| map.id == "mirror")
                .unwrap();
            assert_eq!(metadata.human, human);
            assert!(
                rules
                    .maps
                    .contains_key(&("mirror".to_owned(), metadata.revision))
            );
        }
    }

    #[test]
    fn invalid_scenario_placement_returns_a_content_error() {
        let mut bundle = embedded_bundle();
        let path = "game/scenario/mirror-v1/roster.json";
        let mut roster: serde_json::Value = serde_json::from_str(&bundle[path]).unwrap();
        roster["factions"][0]["units"][0]["tile"] = serde_json::json!({"col":-1,"row":-1});
        bundle.insert(path.to_owned(), serde_json::to_string(&roster).unwrap());
        let error = Rules::from_json_bundle(&bundle).unwrap_err();
        assert_eq!(error.path, "game/scenario/mirror-v1/roster.json");
        assert!(error.message.contains("initial unit is outside its board"));
    }

    #[test]
    fn initial_placements_allow_wounds_but_reject_excess_hp() {
        let mut bundle = embedded_bundle();
        let map = bundle
            .get_mut("game/scenario/mirror-v1/roster.json")
            .unwrap();
        *map = map.replacen(
            "\"type\": \"commander\",",
            "\"type\": \"commander\",\n      \"hp\": 7,",
            1,
        );
        let rules = Rules::from_json_bundle(&bundle).unwrap();
        let state = &rules.maps[&("mirror".to_owned(), 1)];
        assert_eq!(state.units[0].hp, 7);
        assert_eq!(state.units[1].hp, rules.units[rules.types["soldier"]].hp);
        assert_eq!(state.units[0].id, "u1");
        assert_eq!(state.units[0].experience, Some(0));
        assert!(!state.units[0].moved);
        assert!(!state.units[0].attack_spent);
        let map = bundle
            .get_mut("game/scenario/mirror-v1/roster.json")
            .unwrap();
        *map = map.replace("\"hp\": 7,", "\"hp\": 99,");
        let error = Rules::from_json_bundle(&bundle).unwrap_err();
        assert_eq!(error.path, "game/scenario/mirror-v1/roster.json");
        assert!(error.message.contains("initial HP"));
    }

    #[test]
    fn component_references_report_missing_files_and_reject_traversal() {
        let mut bundle = embedded_bundle();
        let path = "game/campaigns/mirror-night/stages/mirror-night/story.json";
        bundle.remove(path);
        assert_eq!(Rules::from_json_bundle(&bundle).unwrap_err().path, path);
        let mut bundle = embedded_bundle();
        let descriptor = bundle
            .get_mut("game/scenario/mirror-v1/scenario.json")
            .unwrap();
        *descriptor = descriptor.replace("roster.json", "../roster.json");
        assert!(
            Rules::from_json_bundle(&bundle)
                .unwrap_err()
                .message
                .contains("traversal")
        );
    }

    #[cfg(all(feature = "wasm", not(target_arch = "wasm32")))]
    #[test]
    fn native_and_embedded_load_only_manifest_referenced_documents() {
        let native =
            Rules::load_from(Path::new(env!("CARGO_MANIFEST_DIR")).join("../data")).unwrap();
        assert_eq!(
            native.content_fingerprint,
            Rules::embedded().unwrap().content_fingerprint
        );
        // Unreferenced files must not create a different catalog on WASM.
        let mut sources = embedded_bundle();
        sources.insert("game/units/unlisted.json".into(), "{}".into());
        let selected = documents::collect_bundle(|path| {
            sources
                .get(path)
                .cloned()
                .ok_or_else(|| ContentError::new(path, "missing document"))
        })
        .unwrap();
        assert!(!selected.contains_key("game/units/unlisted.json"));
        assert_eq!(native.content_fingerprint, content_fingerprint(&selected));
    }
    #[test]
    fn attack_counts_default_to_one_and_reject_invalid_values() {
        let mut bundle = embedded_bundle();
        let path = "game/units/humans/swordsman.json";
        let mut unit: serde_json::Value = serde_json::from_str(&bundle[path]).unwrap();
        unit["attacks"][0].as_object_mut().unwrap().remove("count");
        bundle.insert(path.into(), serde_json::to_string(&unit).unwrap());
        let rules = Rules::from_json_bundle(&bundle).unwrap();
        assert_eq!(rules.units[rules.types["swordsman"]].attacks[0].count, 1);
        for spread in [-1, unit["attacks"][0]["damage"].as_i64().unwrap() + 1] {
            let mut invalid = unit.clone();
            invalid["attacks"][0]["spread"] = serde_json::json!(spread);
            bundle.insert(path.into(), serde_json::to_string(&invalid).unwrap());
            assert_eq!(Rules::from_json_bundle(&bundle).unwrap_err().path, path);
        }
        for count in [0, 17] {
            unit["attacks"][0]["count"] = serde_json::json!(count);
            bundle.insert(path.into(), serde_json::to_string(&unit).unwrap());
            assert_eq!(Rules::from_json_bundle(&bundle).unwrap_err().path, path);
        }
    }
}

fn apply_objective_route(
    campaign: &mut Campaign,
    route: &SimulationObjective,
    path: &str,
) -> Result<(), ContentError> {
    for (stage, plan) in &route.stages {
        if plan.goals.is_some()
            || plan.optional_goals.is_some()
            || !plan.events.is_empty()
            || !plan.event_conditions.is_empty()
        {
            return Err(ContentError::new(
                path,
                "legacy route goals/events are unsupported; use scriptEvents and scriptConditions",
            ));
        }
        let mission = campaign
            .missions
            .iter_mut()
            .find(|m| &m.map.id == stage)
            .ok_or_else(|| {
                ContentError::new(
                    path,
                    format!("objective route references unknown stage {stage}"),
                )
            })?;
        if let Some(goals) = &plan.goals {
            mission.goals = goals.clone();
        }
        if let Some(goals) = &plan.optional_goals {
            mission.optional_goals = goals.clone();
        }
        mission.events.extend(plan.events.clone());
        mission.scripted_events.extend(plan.script_events.clone());
        for (id, condition) in &plan.script_conditions {
            let event = mission
                .scripted_events
                .iter_mut()
                .find(|e| &e.id == id)
                .ok_or_else(|| ContentError::new(path, format!("unknown script event {id}")))?;
            event.when = condition.clone();
        }
        for (id, condition) in &plan.event_conditions {
            let event = mission
                .events
                .iter_mut()
                .find(|e| &e.id == id)
                .ok_or_else(|| {
                    ContentError::new(
                        path,
                        format!("objective route references unknown event {id}"),
                    )
                })?;
            let Trigger::Condition {
                condition: current, ..
            } = &mut event.trigger
            else {
                return Err(ContentError::new(
                    path,
                    "eventConditions requires a condition-triggered event",
                ));
            };
            *current = condition.clone();
        }
        mission
            .scripted_events
            .sort_by_key(|event| std::cmp::Reverse(event.priority));
        for event in &mut mission.scripted_events {
            event.when.index_holds();
        }
    }
    Ok(())
}
impl Rules {
    /// Resolve a simulation-only campaign while sharing the rest of the catalog.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn prepare_simulation_campaign(
        &self,
        campaign: &str,
        route: &str,
    ) -> Result<std::borrow::Cow<'_, CampaignRules>, ContentError> {
        let authored = self.campaigns.get(campaign).ok_or_else(|| {
            ContentError::new(
                "simulation/campaign.json",
                format!("unknown campaign {campaign}"),
            )
        })?;
        if route == "authored" {
            return Ok(std::borrow::Cow::Borrowed(authored));
        }
        let plan = self
            .campaign_defaults
            .campaigns
            .get(campaign)
            .and_then(|config| config.routes.get(route))
            .ok_or_else(|| {
                ContentError::new(
                    "simulation/campaign.json",
                    format!("unknown objective route {route} for {campaign}"),
                )
            })?;
        identifier(route, "simulation/campaign.json")?;
        if plan.stages.is_empty() {
            return Err(ContentError::new(
                "simulation/campaign.json",
                "objective routes need stages",
            ));
        }
        for stage in plan.stages.keys() {
            if !authored
                .missions
                .iter()
                .any(|mission| &mission.map.id == stage)
            {
                return Err(ContentError::new(
                    "simulation/campaign.json",
                    format!("objective route references unknown stage {stage}"),
                ));
            }
        }
        let changes_definition = plan.stages.values().any(|stage| {
            stage.goals.is_some()
                || stage.optional_goals.is_some()
                || !stage.script_events.is_empty()
                || !stage.script_conditions.is_empty()
                || !stage.events.is_empty()
                || !stage.event_conditions.is_empty()
        });
        let mut selected = std::borrow::Cow::Borrowed(authored);
        if changes_definition {
            apply_objective_route(selected.to_mut(), plan, "simulation/campaign.json")?;
        }
        if changes_definition {
            let characters = selected.characters.clone();
            for mission in &mut selected.to_mut().missions {
                let state = self
                    .maps
                    .iter()
                    .find(|((id, _), _)| id == &mission.map.id)
                    .map(|(_, state)| state)
                    .ok_or_else(|| {
                        ContentError::new("simulation/campaign.json", "unknown route stage map")
                    })?;
                validate_character_references(
                    mission,
                    state,
                    &characters,
                    "simulation/campaign.json",
                )?;
            }
        }
        for mission in &selected.missions {
            let state = self
                .maps
                .iter()
                .find(|((id, _), _)| id == &mission.map.id)
                .map(|(_, state)| state)
                .ok_or_else(|| {
                    ContentError::new("simulation/campaign.json", "unknown route stage map")
                })?;
            if changes_definition {
                validate_mission(
                    mission,
                    state,
                    &self.types,
                    &self.units,
                    &self.terrains,
                    "simulation/campaign.json",
                )?;
            }
            if let Some(stage) = plan.stages.get(&mission.map.id) {
                if let Some(condition) = &stage.ignore_optional_when {
                    condition
                        .validate(&state.tiles, &mission.events, false)
                        .map_err(|e| ContentError::new("simulation/campaign.json", e))?;
                    condition
                        .validate_characters(&selected.characters)
                        .map_err(|e| ContentError::new("simulation/campaign.json", e))?;
                    condition
                        .validate_references(&self.types, &state.factions)
                        .map_err(|e| ContentError::new("simulation/campaign.json", e))?;
                }
            }
        }
        Ok(selected)
    }
}
