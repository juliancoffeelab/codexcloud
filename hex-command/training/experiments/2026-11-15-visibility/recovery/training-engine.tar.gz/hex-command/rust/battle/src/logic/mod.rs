//! Battle rules and campaign transitions, independent of transport and policy.
pub(crate) mod battle;
pub(crate) mod combat;
mod commands;
pub mod damage;
pub(crate) mod event_queries;
mod event_state;
pub(crate) mod events;
pub mod exchange;
mod execution;
mod factions;
pub(crate) mod inspection;
mod items;
pub(crate) mod movement;
mod perception;
pub(crate) use perception::Perception;
mod recruit_pool;
mod restore;
mod turns;
mod visibility;
pub use restore::{StateError, validate_state};
#[cfg(not(target_arch = "wasm32"))]
pub use restore::{validate_state_geometry, validate_state_geometry_with_campaign};
pub mod campaign;
pub(crate) use battle::{BattlePosition, LiveBattle};

pub mod geometry;

pub mod conditions;
