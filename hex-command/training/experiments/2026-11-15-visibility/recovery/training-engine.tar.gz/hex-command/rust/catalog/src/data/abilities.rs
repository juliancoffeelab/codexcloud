//! Named authored rule fragments are expanded once, before typed catalog validation.
use serde::Deserialize;

#[cfg_attr(feature = "wasm", ocamljsify::ocamljsify(borrow))]
#[derive(Clone, Debug, serde::Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
#[cfg_attr(
    any(feature = "bake", all(feature = "wasm", target_arch = "wasm32")),
    derive(hex_catalog_freeze_derive::Freeze)
)]
pub struct AbilityInfo {
    pub id: String,
    pub name: String,
    pub description: String,
    #[serde(default)]
    pub perception: Option<crate::data::UnitPerception>,
}
#[cfg(any(not(target_arch = "wasm32"), feature = "runtime-catalog"))]
#[path = "ability_loader.rs"]
mod loader;
#[cfg(any(not(target_arch = "wasm32"), feature = "runtime-catalog"))]
pub(super) use loader::resolve_bundle;
