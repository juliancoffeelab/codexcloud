# Engine-owned scenarios and workloads

`manifest.json` is the single registry read by Rust for native and browser
engines. Scenario geometry and rosters live in `game/scenario/`; campaign stages
keep their maps, rosters, scripts and story together in `game/campaigns/`.
Frontend code receives resolved metadata through the engine API.

Every `scenario.json` and `campaign.json` declares `human: true` or `false`.
The engine exposes complete metadata for rendering and loading all registered
content, including historical map revisions. The frontend filters new-game
selection lists by `human`; this does not restrict loading or debug launchers.
Standalone scenarios can declare `characters` when their roster contains named
actors. Map identifiers and revisions remain the engine's loading keys.

Workload manifests reference these registered definitions:

- `simulation/arena.json` defines named arena groups, their fixed map variants,
  capture territory, holding duration and default schedule. Each variant either
  selects match armies with an explicit total budget or retains the scenario's
  forces and economies. Positive match seeds cycle through variants in manifest order; seed zero
  selects the first variant. The seed still independently controls combat and AI decisions. Terrain is loaded from
  the scenario, with no runtime generation or fallback template.
- `simulation/campaign.json` defines default campaign selection, diplomacy modes
  and simulation-only objective routes. These settings do not change the
  human-playable campaign definitions.
- `simulation/rl.json` selects existing arena groups, roster pairs, objective
  modes, campaign routes, opponents and recruiters for mixed learning. Python
  obtains this validated definition from Rust and adds sampling/seeding budgets.

The four frozen cases per original arena group preserve the old generator's
seeds 1–4, including their budgets. Identical boards share one map file. Other
seeds select from those cases; they do not reproduce the old procedural layouts.
The event-free Villages and Sluice combat scenarios are registered alongside the
other maps rather than rebuilt by a separate training loader.

Catalog schema changes are independent of saved-battle formats. Immutable old
experiment catalogs remain paired with their recorded engine; new training runs
use the current catalog and a policy warm start when provenance changes.

## Illumination and sight modifiers

Illumination has three levels: `lit`, `unlit`, and `darkness`. Daytime outdoor
cells default to lit, nighttime cells to unlit, and underground cells to darkness.
A tile can override its ambient level through `perception.illumination`. Light
emitters raise affected tiles to lit, including in projected movement queries.
Darkness alone does not conceal terrain or occupants: fog and personal concealment
remain independent rules.

Unit definitions can add target-lighting adjustments alongside `perception`:

```json
{
  "perception": { "range": 7 },
  "sightModifiers": { "lit": 0, "unlit": 0, "darkness": -3 }
}
```

The resolved finite range, including equipment, is adjusted for illumination at
the target tile and clamped between zero and 65535. Modifiers default to zero;
unlimited sight remains unlimited. Modifiers belong to unit catalog definitions,
not per-unit effects or fixed sight-source profiles.

Concealment conditions accept a nonempty list of distinct illumination levels.
For example, Darkcloak can use `"requires": { "illumination": ["darkness"] }`.
An ability can allow both ordinary night and darkness by listing both. Darkness
penetration bypasses darkness concealment, not numeric sight penalties; a
Darkvision unit can author a zero darkness penalty and its own base sight range.

## Reusable abilities

Register named definitions from `rust/data/abilities/` in the manifest's
`abilities` list. A definition has `id`, `name`, `description`, a `rules` object,
and optional `includes` names. Units can declare `"abilities": ["forestcloak"]`.
The loader expands those rule fragments before ordinary typed content validation;
runtime rules and saves contain resolved mechanics, not ability references.
Unit metadata retains `abilityIds`, and catalog metadata exposes ability labels.

References work in other authored objects too. To reuse just a profile inside an
item's `perception` or a scripted perception effect, select its rule section:
`"abilities": [{ "id": "darkcloak", "section": "perception" }]`. The destination
must support those fields; normal catalog validation rejects incompatible uses.

Included abilities are resolved first. Rule objects merge recursively, arrays
combine without duplicate values, and conflicting scalar values from separate
abilities are rejected. Explicit fields on the consuming object override scalar
defaults. Unknown IDs, duplicate references, missing sections and cycles fail
with the source document in the error. No filesystem or registry lookup occurs
in sight queries or restoration.
