"""Archive this completed extension without altering the original experiment."""
from pathlib import Path
from collections import Counter
import json,gzip,shutil,hashlib
ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parents[2]/'training/experiments/2026-11-24-ppo-hour10-12h'
DEST=PARENT/'extension-twelve-hours-20261126'
e=json.loads((ROOT/'extension-twelve-hours.json').read_text());done=json.loads((ROOT/'finished.json').read_text());records=json.loads((ROOT/'evaluation/hourly-summary.json').read_text())
assert done['training']['elapsed']>=e['total_target_seconds'] and [r['hour'] for r in records]==list(range(25))
original=json.loads((PARENT/'archive-manifest.json').read_text())
for name,m in original.items():assert hashlib.sha256((PARENT/name).read_bytes()).hexdigest()==m['sha256'],name

def copy(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def gzbytes(b,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(gzip.compress(b,mtime=0))
def gz(src,dst):gzbytes(src.read_bytes(),dst)
for name in ['finished.json','extension-twelve-hours.json','extension-state-verification.json','extension-launch-verification.json','protocol.json','runtime-versions.json','checkpoint-index.json','health.json','snapshot-error.json']:
 if (ROOT/name).exists():copy(ROOT/name,DEST/name)
for name in ['supervisor.py','eval_runner.py','extra_plots.py','monitor_check.py','lantern_curves.py','summarize_completed.py','archive_extension.py','python/hex_command_rl/mixed_ppo.py']:
 gz(ROOT/name,DEST/'scripts'/(name+'.gz'))
for name in ['trainer.log','evaluator.log','supervisor.log']:
 old=gzip.decompress((PARENT/(name+'.gz')).read_bytes());current=(ROOT/name).read_bytes();assert current.startswith(old),name;gzbytes(current[len(old):],DEST/(name+'.gz'))
old=gzip.decompress((PARENT/'rl/metrics.jsonl.gz').read_bytes());current=(ROOT/'rl/metrics.jsonl').read_bytes();assert current.startswith(old);gzbytes(current[len(old):],DEST/'rl/metrics.jsonl.gz')
rows=[json.loads(line) for line in (ROOT/'allocation-history.jsonl').read_text().splitlines()];new=[x for x in rows if x['time']>=e['created']];gzbytes((''.join(json.dumps(x)+'\n' for x in new)).encode(),DEST/'allocation-history.jsonl.gz')
gz(ROOT/'rl/sampler-status.json',DEST/'rl/sampler-status.json.gz');gz(ROOT/'extension-initial-sampler.json',DEST/'initial-sampler-status.json.gz')
for name in ['parameters.json','status.json','complete.json','latest.json','best.json']:
 if (ROOT/'rl'/name).exists():copy(ROOT/'rl'/name,DEST/'rl'/name)
for p in (ROOT/'monitor-checks').glob('*.json'):
 if json.loads(p.read_text()).get('time',0)>=e['created']:copy(p,DEST/'monitor'/p.name)
for name in ['hourly-summary.json','selection.json','complete.json','comparison-and-chapters.json','per-map-and-chapter-curves.json','lantern-focused-curves.json']:
 copy(ROOT/'evaluation'/name,DEST/'evaluation'/name)
for hour in range(13,25):
 for p in (ROOT/f'evaluation/hour-{hour:02d}').rglob('*'):
  if p.is_file() and p.suffix in ['.json','.jsonl']:gz(p,DEST/p.relative_to(ROOT).with_name(p.name+'.gz'))
for p in (ROOT/'plots').glob('*.png'):copy(p,DEST/'plots'/p.name)
checkpoints=[]
for record in records[12:]:
 hour=record['hour'];model=Path(record['model']);folder=model.parent;manifest=json.loads((folder/'manifest.json').read_text())
 for name,m in manifest['files'].items():
  b=(folder/name).read_bytes();assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
  shared=Path('/workspace/shared')/ROOT.name/'rl/checkpoints'/folder.name/name;assert hashlib.sha256(shared.read_bytes()).hexdigest()==m['sha256']
  gzbytes(b,DEST/f'recovery/hour-{hour:02d}'/(name+'.gz'))
 gz(folder/'manifest.json',DEST/f'recovery/hour-{hour:02d}/manifest.json.gz')
 checkpoints.append(dict(hour=hour,actual_seconds=record['actual_seconds'],extension_seconds=record['actual_seconds']-e['start_saved_seconds'],source_folder=str(folder.relative_to(ROOT)),model_sha256=hashlib.sha256(model.read_bytes()).hexdigest(),archive=f'recovery/hour-{hour:02d}/planner.json.gz'))
(DEST/'hourly-checkpoints.json').write_text(json.dumps(checkpoints,indent=2)+'\n')
for panel,n in [('heldout',312),('training_diagnostic',214),('lantern_showcase',24)]:
 baseline=None
 for hour in range(25):
  d=json.loads((ROOT/f'evaluation/hour-{hour:02d}/monitor/{panel}.json').read_text());assert len(d['rows'])==d['runs']==n
  assert d['model_sha256']==hashlib.sha256(Path(records[hour]['model']).read_bytes()).hexdigest()
  configs=Counter(json.dumps(row['config'],sort_keys=True) for row in d['rows'])
  if baseline is None:baseline=configs
  assert configs==baseline,(panel,hour)
for name,m in original.items():assert hashlib.sha256((PARENT/name).read_bytes()).hexdigest()==m['sha256'],name
print('Archived extension only; original archive unchanged. Validated 13 recovery bundles, all 13750 fixed-panel results and checkpoint/config identities.')
